set -e

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd /opt/high-games

echo "=== BACKUP DO AGENTE ATUAL ==="
mkdir -p /opt/high-games/backups /opt/high-games/agent /opt/high-games/agent-data
if [ -f /opt/high-games/agent/server.js ]; then
  cp /opt/high-games/agent/server.js "/opt/high-games/backups/server.js.$(date +%Y%m%d-%H%M%S)"
fi

echo "=== ATUALIZANDO SOMENTE O AGENTE ==="
cp "$SCRIPT_DIR/agent-admin-server.js" /opt/high-games/agent/server.js

grep -q '^ADMIN_PASSWORD=' .env || echo "ADMIN_PASSWORD=highgames$(openssl rand -hex 4)" >> .env
grep -q '^AI_PROVIDER=' .env || echo 'AI_PROVIDER=gemini' >> .env
grep -q '^GEMINI_MODEL=' .env || echo 'GEMINI_MODEL=gemini-2.5-flash-lite' >> .env
grep -q '^GROK_MODEL=' .env || echo 'GROK_MODEL=grok-4-fast' >> .env
grep -q '^STRICT_WEBHOOK_AUTH=' .env || echo 'STRICT_WEBHOOK_AUTH=false' >> .env
grep -q './agent-data:/data' docker-compose.yml || sed -i '/- \.\/agent:\/app:ro/a\      - ./agent-data:/data' docker-compose.yml

python3 - <<'PY'
import json
from pathlib import Path

p = Path('/opt/high-games/agent-data/state.json')
if p.exists():
    data = json.loads(p.read_text())
    data.setdefault('settings', {})
    data['settings']['maxOutputTokens'] = max(int(data['settings'].get('maxOutputTokens') or 0), 2048)
    data['settings']['temperature'] = float(data['settings'].get('temperature') or 0.45)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2))
PY

echo "=== REINICIANDO SOMENTE O AGENTE ==="
docker compose up -d --force-recreate agent

echo "=== TESTE DE SAUDE ==="
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:3000/health >/tmp/high-games-health.json; then
    break
  fi
  sleep 2
done
curl -fsS http://127.0.0.1:3000/health >/tmp/high-games-health.json
cat /tmp/high-games-health.json
echo

echo "=== TESTE INTERNO DO WEBHOOK ==="
curl -fsS -X POST "http://127.0.0.1:3000/webhook?dryRun=1" \
  -H 'content-type: application/json' \
  --data '{"event":"MESSAGES_UPSERT","messages":[{"from":"5599999999999","text":"nao recebi meu produto"}]}' \
  >/tmp/high-games-webhook-test.json
cat /tmp/high-games-webhook-test.json
echo

echo "=== CONTAINERS ==="
docker compose ps --format 'table {{.Name}}\t{{.State}}\t{{.Status}}'

echo "=== LOGS RECENTES DO AGENTE ==="
docker compose logs --tail=40 agent

echo "=== RESULTADO ==="
echo "Painel: http://2.24.114.225:3000/admin"
echo "Usuario: admin"
grep '^ADMIN_PASSWORD=' .env
