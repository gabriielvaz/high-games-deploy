set -e
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd /opt/high-games

mkdir -p /opt/high-games/agent /opt/high-games/agent-data
cp "$SCRIPT_DIR/agent-admin-server.js" /opt/high-games/agent/server.js

grep -q '^ADMIN_PASSWORD=' .env || echo "ADMIN_PASSWORD=highgames$(openssl rand -hex 4)" >> .env
grep -q '^AI_PROVIDER=' .env || echo 'AI_PROVIDER=gemini' >> .env
grep -q '^GEMINI_MODEL=' .env && sed -i 's#^GEMINI_MODEL=.*#GEMINI_MODEL=gemini-2.5-flash-lite#' .env || echo 'GEMINI_MODEL=gemini-2.5-flash-lite' >> .env
grep -q '^GROK_MODEL=' .env || echo 'GROK_MODEL=grok-4-fast' >> .env
grep -q './agent-data:/data' docker-compose.yml || sed -i '/- \.\/agent:\/app:ro/a\      - ./agent-data:/data' docker-compose.yml

python3 - <<'PY'
import json
from pathlib import Path

p = Path('/opt/high-games/agent-data/state.json')
if p.exists():
    data = json.loads(p.read_text())
    data.setdefault('settings', {})
    data['settings']['maxOutputTokens'] = max(int(data['settings'].get('maxOutputTokens') or 0), 2048)
    data['settings']['temperature'] = float(data['settings'].get('temperature') or 0.45)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2))
PY

docker compose up -d --force-recreate agent

echo "Painel: http://2.24.114.225:3000/admin"
echo "Usuario: admin"
grep '^ADMIN_PASSWORD=' .env
