set -e
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd /opt/high-games

mkdir -p /opt/high-games/agent /opt/high-games/agent-data
cp "$SCRIPT_DIR/agent-admin-server.js" /opt/high-games/agent/server.js

grep -q '^ADMIN_PASSWORD=' .env || echo "ADMIN_PASSWORD=highgames$(openssl rand -hex 4)" >> .env
grep -q '^WEBHOOK_TOKEN=' .env || echo "WEBHOOK_TOKEN=$(openssl rand -hex 20)" >> .env
grep -q '^AI_PROVIDER=' .env || echo 'AI_PROVIDER=gemini' >> .env
grep -q '^GEMINI_MODEL=' .env && sed -i 's#^GEMINI_MODEL=.*#GEMINI_MODEL=gemini-2.5-flash-lite#' .env || echo 'GEMINI_MODEL=gemini-2.5-flash-lite' >> .env
grep -q '^GROK_MODEL=' .env || echo 'GROK_MODEL=grok-4-fast' >> .env
grep -q './agent-data:/data' docker-compose.yml || sed -i '/- \.\/agent:\/app:ro/a\      - ./agent-data:/data' docker-compose.yml

python3 - <<'PY'
import json
from pathlib import Path

p = Path('/opt/high-games/agent-data/state.json')
if p.exists():
    data = json.loads(p.read_text())
    data.setdefault('settings', {})
    data['settings']['maxOutputTokens'] = max(int(data['settings'].get('maxOutputTokens') or 0), 2048)
    data['settings']['temperature'] = float(data['settings'].get('temperature') or 0.45)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2))
PY

docker compose up -d --force-recreate agent

echo "Aguardando agente responder..."
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:3000/health >/tmp/high-games-health.json; then
    break
  fi
  sleep 2
done
curl -fsS http://127.0.0.1:3000/health >/tmp/high-games-health.json
cat /tmp/high-games-health.json
echo

echo "Testando webhook interno do agente..."
WEBHOOK_TOKEN_VALUE="$(grep '^WEBHOOK_TOKEN=' .env | tail -1 | cut -d= -f2-)"
curl -fsS -X POST "http://127.0.0.1:3000/webhook?token=${WEBHOOK_TOKEN_VALUE}&dryRun=1" \
  -H 'content-type: application/json' \
  --data '{"event":"MESSAGES_UPSERT","messages":[{"from":"5599999999999","text":"nao recebi meu produto"}]}' \
  >/tmp/high-games-webhook-test.json
cat /tmp/high-games-webhook-test.json
echo

echo "Configurando webhook da Evolution..."
python3 - <<'PY'
import json
import urllib.error
import urllib.request
from pathlib import Path

env = {}
for line in Path(".env").read_text(errors="ignore").splitlines():
    if "=" in line and not line.lstrip().startswith("#"):
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")

api_key = env.get("AUTHENTICATION_API_KEY") or env.get("EVOLUTION_API_KEY") or ""
instance = env.get("INSTANCE_NAME") or env.get("EVOLUTION_INSTANCE") or "high-games"
token = env.get("WEBHOOK_TOKEN") or ""
url = f"http://agent:3000/webhook?token={token}"

if not api_key:
    print("AUTHENTICATION_API_KEY ausente; pulando configuracao automatica do webhook.")
    raise SystemExit(0)

endpoint = f"http://127.0.0.1:8080/webhook/set/{instance}"
payloads = [
    {"webhook": {"enabled": True, "url": url, "webhookUrl": url, "byEvents": False, "base64": False, "webhookByEvents": False, "webhookBase64": False, "events": ["MESSAGES_UPSERT"]}},
    {"webhook": {"enabled": True, "url": url, "byEvents": False, "base64": False, "events": ["MESSAGES_UPSERT"]}},
    {"webhook": {"webhookUrl": url, "webhookByEvents": False, "webhookBase64": False, "events": ["MESSAGES_UPSERT"]}},
]

last = ""
for payload in payloads:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(endpoint, data=data, method="POST", headers={"content-type": "application/json", "apikey": api_key})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            body = resp.read().decode(errors="ignore")
            print(body[:1000])
            raise SystemExit(0)
    except urllib.error.HTTPError as exc:
        last = exc.read().decode(errors="ignore")
    except Exception as exc:
        last = str(exc)

print("Nao foi possivel configurar webhook automaticamente.")
print(last[:1000])
PY

echo "Estado da conexao WhatsApp na Evolution:"
python3 - <<'PY'
import urllib.request
from pathlib import Path

env = {}
for line in Path(".env").read_text(errors="ignore").splitlines():
    if "=" in line and not line.lstrip().startswith("#"):
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")
api_key = env.get("AUTHENTICATION_API_KEY") or env.get("EVOLUTION_API_KEY") or ""
instance = env.get("INSTANCE_NAME") or env.get("EVOLUTION_INSTANCE") or "high-games"
if not api_key:
    raise SystemExit(0)
req = urllib.request.Request(f"http://127.0.0.1:8080/instance/connectionState/{instance}", headers={"apikey": api_key})
try:
    with urllib.request.urlopen(req, timeout=8) as resp:
        print(resp.read().decode(errors="ignore")[:1000])
except Exception as exc:
    print(f"Nao consegui consultar estado: {exc}")
PY

echo "Painel: http://2.24.114.225:3000/admin"
echo "Usuario: admin"
grep '^ADMIN_PASSWORD=' .env
