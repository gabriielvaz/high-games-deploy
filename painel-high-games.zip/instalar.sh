set -e
cd /opt/high-games
mkdir -p /opt/high-games/agent /opt/high-games/agent-data
cp /tmp/agent-admin-server.js /opt/high-games/agent/server.js
grep -q '^ADMIN_PASSWORD=' .env || echo "ADMIN_PASSWORD=highgames$(openssl rand -hex 4)" >> .env
grep -q '^GEMINI_MODEL=' .env && sed -i 's#^GEMINI_MODEL=.*#GEMINI_MODEL=gemini-3.5-flash#' .env || echo 'GEMINI_MODEL=gemini-3.5-flash' >> .env
grep -q './agent-data:/data' docker-compose.yml || sed -i '/- \.\/agent:\/app:ro/a\      - ./agent-data:/data' docker-compose.yml
docker compose up -d --force-recreate agent
echo "Painel: http://2.24.114.225:3000/admin"
echo "Usuario: admin"
grep '^ADMIN_PASSWORD=' .env
