import http from "node:http";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";

const port = Number(process.env.PORT || 3000);
const instance = process.env.INSTANCE_NAME || "high-games";
const dataDir = process.env.DATA_DIR || "/data";
const stateFile = `${dataDir}/state.json`;

const defaults = {
  settings: {
    aiEnabled: true,
    maxOutputTokens: 2048,
    temperature: 0.55,
    systemPrompt:
      "Voce e o agente da High Games no WhatsApp. Seja claro, humano, consultivo e objetivo. Use historico e treinamento. Nao invente preco, link, prazo, garantia ou catalogo. Nao oriente pirataria, ROM ilegal, BIOS ilegal ou violacao de direitos autorais. Quando faltar informacao, faca uma pergunta objetiva.",
    businessKnowledge:
      "A High Games atende clientes que querem jogar titulos compativeis com emulador de PS2 no celular. Ajude em compra, instalacao, configuracao, travamentos, controles, desempenho e suporte pos-venda. Pergunte jogo desejado e modelo do celular quando fizer sentido."
  },
  training: [
    {
      id: "venda",
      title: "Venda",
      content:
        "Quando o cliente quiser comprar, pedir o jogo desejado e o modelo do celular. Nao inventar preco ou link. Conduzir de forma consultiva."
    },
    {
      id: "suporte",
      title: "Suporte",
      content:
        "Para travamentos, pedir modelo do celular, RAM e jogo. Sugerir ajustes de desempenho sem prometer compatibilidade perfeita."
    }
  ],
  conversations: {}
};

let state = await loadState();

http.createServer(async (req, res) => {
  try {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const bodyText = Buffer.concat(chunks).toString("utf8");
    const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

    if (url.pathname === "/health") {
      return sendJson(res, 200, {
        ok: true,
        ai: Boolean(process.env.GEMINI_API_KEY),
        model: process.env.GEMINI_MODEL || null
      });
    }

    if (url.pathname === "/webhook") return handleWebhook(req, res, url, bodyText);

    if (url.pathname === "/admin") {
      if (!isAuthorized(req)) return unauthorized(res);
      return sendHtml(res, adminHtml());
    }

    if (url.pathname.startsWith("/api/")) {
      if (!isAuthorized(req)) return unauthorized(res);
      return handleApi(req, res, url, bodyText);
    }

    return sendJson(res, 404, { ok: false });
  } catch (error) {
    console.error("Erro HTTP", error);
    return sendJson(res, 500, { ok: false, error: "internal_error" });
  }
}).listen(port, "0.0.0.0", () => console.log(`High Games agent admin listening on ${port}`));

async function handleWebhook(req, res, url, bodyText) {
  const token = url.searchParams.get("token") || req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (process.env.WEBHOOK_TOKEN && token !== process.env.WEBHOOK_TOKEN) return sendJson(res, 401, { ok: false });

  const payload = JSON.parse(bodyText || "{}");
  const messages = extractMessages(payload);
  console.log("Webhook recebido", JSON.stringify({ event: payload.event, messages: messages.map(m => ({ from: m.from, text: m.text })) }));

  for (const message of messages) {
    saveMessage(message.from, "cliente", message.text);
    const conversation = state.conversations[message.from];
    if (conversation?.humanMode) continue;

    const reply = state.settings.aiEnabled
      ? await generateAiReply(message.from, message.text)
      : "Recebi sua mensagem. Uma pessoa da equipe vai continuar o atendimento.";

    saveMessage(message.from, "agente", reply);
    console.log("Enviando resposta", JSON.stringify({ to: message.from, reply }));
    await sendEvolutionText(message.from, reply);
  }

  await persist();
  return sendJson(res, 200, { ok: true, received: messages.length });
}

async function handleApi(req, res, url, bodyText) {
  if (url.pathname === "/api/state" && req.method === "GET") return sendJson(res, 200, publicState());

  if (url.pathname === "/api/settings" && req.method === "POST") {
    state.settings = { ...state.settings, ...JSON.parse(bodyText || "{}") };
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/training" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    if (!body.title || !body.content) return sendJson(res, 400, { ok: false });
    const item = { id: body.id || `${Date.now()}`, title: body.title, content: body.content };
    state.training = [item, ...state.training.filter(x => x.id !== item.id)];
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/training" && req.method === "DELETE") {
    const body = JSON.parse(bodyText || "{}");
    state.training = state.training.filter(x => x.id !== body.id);
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/test-reply" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    const contact = body.contact || "__training_test__";
    if (body.message) saveMessage(contact, "cliente", body.message);
    const reply = await generateAiReply(contact, body.message || "Oi, quero comprar");
    if (body.message) saveMessage(contact, "agente", reply);
    await persist();
    return sendJson(res, 200, { ok: true, reply });
  }

  if (url.pathname === "/api/conversation" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    const c = ensureConversation(body.contact);
    if (typeof body.humanMode === "boolean") c.humanMode = body.humanMode;
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/send" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    saveMessage(body.contact, "humano", body.text);
    await sendEvolutionText(body.contact, body.text);
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  return sendJson(res, 404, { ok: false });
}

function extractMessages(payload) {
  const raw = Array.isArray(payload?.data) ? payload.data : [payload?.data || payload];
  const out = [];
  for (const item of raw) {
    const key = item?.key;
    if (!key || key.fromMe) continue;
    const remoteJid = item.senderPn || item.key.remoteJidAlt || item.key.remoteJid || item.remoteJid || payload.sender || "";
    if (remoteJid.includes("@g.us")) continue;
    const text = (item.message?.conversation || item.message?.extendedTextMessage?.text || item.message?.imageMessage?.caption || item.message?.videoMessage?.caption || "").trim();
    if (text) out.push({ from: jidToRecipient(remoteJid), text });
  }
  return out;
}

async function generateAiReply(contact, input) {
  if (!process.env.GEMINI_API_KEY) return fallbackReply();

  const model = process.env.GEMINI_MODEL || "gemini-3.5-flash";
  const c = ensureConversation(contact);
  const history = c.messages.slice(-12).map(m => `${m.role}: ${m.text}`).join("\n");
  const training = state.training.map(t => `Titulo: ${t.title}\nConteudo: ${t.content}`).join("\n\n");
  const prompt = [
    state.settings.systemPrompt,
    "",
    "Base fixa do negocio:",
    state.settings.businessKnowledge,
    "",
    "Base de treinamento cadastrada:",
    training || "Nenhum treinamento cadastrado.",
    "",
    "Historico recente da conversa:",
    history || "Sem historico anterior.",
    "",
    `Mensagem atual do cliente: ${input}`,
    "",
    "Responda de forma completa, finalize a frase e nao corte no meio. Seja breve quando possivel, mas entregue uma resposta inteira. Nao use markdown."
  ].join("\n");

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: Number(state.settings.temperature || 0.55),
          maxOutputTokens: Number(state.settings.maxOutputTokens || 900)
        }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Erro Gemini", response.status, JSON.stringify(data));
      return fallbackReply();
    }
    const candidate = data.candidates?.[0] || {};
    const answer = String(candidate.content?.parts?.[0]?.text || "").replace(/\s+/g, " ").trim();
    console.log("Gemini respondeu", JSON.stringify({ finishReason: candidate.finishReason || null, preview: answer.slice(0, 180) }));
    return answer || fallbackReply();
  } catch (error) {
    console.error("Falha Gemini", error);
    return fallbackReply();
  }
}

async function sendEvolutionText(number, text) {
  const baseUrl = process.env.EVOLUTION_BASE_URL || "http://evolution-api:8080";
  const response = await fetch(`${baseUrl}/message/sendText/${instance}`, {
    method: "POST",
    headers: { apikey: process.env.EVOLUTION_API_KEY, "content-type": "application/json" },
    body: JSON.stringify({ number, text, delay: 900, linkPreview: false })
  });
  if (!response.ok) console.error("sendText failed", response.status, await response.text());
}

function saveMessage(contact, role, text) {
  const c = ensureConversation(contact);
  c.updatedAt = new Date().toISOString();
  c.messages.push({ role, text, at: c.updatedAt });
  c.messages = c.messages.slice(-80);
}

function ensureConversation(contact) {
  state.conversations[contact] ||= { contact, humanMode: false, updatedAt: new Date().toISOString(), messages: [] };
  return state.conversations[contact];
}

function publicState() {
  return {
    settings: state.settings,
    training: state.training,
    conversations: Object.values(state.conversations).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  };
}

async function loadState() {
  await mkdir(dataDir, { recursive: true });
  if (!existsSync(stateFile)) return structuredClone(defaults);
  return { ...structuredClone(defaults), ...JSON.parse(await readFile(stateFile, "utf8")) };
}

async function persist() { await writeFile(stateFile, JSON.stringify(state, null, 2)); }
function fallbackReply() { return "Estou com uma instabilidade na IA agora, mas consigo te ajudar. Me diga qual jogo voce quer jogar e qual e o modelo do seu celular."; }
function jidToRecipient(v) { const jid = String(v || ""); if (jid.endsWith("@lid")) return jid; return jid.split("@")[0].replace(/\D/g, ""); }

function isAuthorized(req) {
  if (!process.env.ADMIN_PASSWORD) return true;
  const auth = req.headers.authorization || "";
  if (!auth.startsWith("Basic ")) return false;
  const [, pass] = Buffer.from(auth.slice(6), "base64").toString("utf8").split(":");
  return pass === process.env.ADMIN_PASSWORD;
}

function unauthorized(res) { res.writeHead(401, { "www-authenticate": 'Basic realm="High Games Admin"' }); res.end("Login necessario"); }
function sendJson(res, status, body) { res.writeHead(status, { "content-type": "application/json; charset=utf-8" }); res.end(JSON.stringify(body)); }
function sendHtml(res, html) { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(html); }

function adminHtml() {
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>High Games Admin</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;background:#f4f5f7;color:#14171f}header{position:sticky;top:0;z-index:2;background:#111827;color:white;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;box-shadow:0 2px 14px #0002}header strong{font-size:18px}.pill{border:1px solid #334155;background:#1f2937;color:#dbeafe;padding:6px 9px;border-radius:999px;font-size:12px}main{display:grid;grid-template-columns:360px 1fr;min-height:calc(100vh - 60px)}aside{border-right:1px solid #e5e7eb;background:#fff;overflow:auto}.sideTitle{padding:16px 16px 8px;color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.row{padding:14px 16px;border-bottom:1px solid #eef0f3;cursor:pointer}.row:hover{background:#f8fafc}.row b{display:block;margin-bottom:5px}.row small{display:block;color:#6b7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}button,input,textarea{font:inherit}button{border:0;background:#111827;color:white;padding:10px 13px;border-radius:8px;cursor:pointer}button:hover{filter:brightness(1.08)}.ghost{background:#e5e7eb;color:#111827}.danger{background:#b91c1c}.panel{padding:20px;max-width:1120px}.hero{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}.card{background:white;border:1px solid #e5e7eb;border-radius:8px;padding:16px;margin-bottom:16px;box-shadow:0 1px 4px #0000000d}.messages{display:flex;flex-direction:column;gap:10px;margin-bottom:16px}.msg{max-width:820px;padding:11px 13px;border-radius:8px;background:white;border:1px solid #e5e7eb;line-height:1.4}.cliente{align-self:flex-start}.agente{align-self:flex-end;background:#e8f2ff;border-color:#bfdbfe}.humano{align-self:flex-end;background:#e9f9ef;border-color:#bbf7d0}textarea,input{width:100%;border:1px solid #d1d5db;border-radius:8px;padding:11px;background:white}textarea{min-height:112px;resize:vertical}.grid{display:grid;gap:12px}.two{grid-template-columns:1fr 1fr}.tabs{display:flex;gap:8px;flex-wrap:wrap}.tabs button{background:#374151}.hide{display:none}.muted{color:#6b7280}.toolbar{display:flex;gap:8px;flex-wrap:wrap}.result{white-space:pre-wrap;background:#0f172a;color:#e5e7eb;border-radius:8px;padding:12px;min-height:48px}@media(max-width:840px){main{grid-template-columns:1fr}aside{max-height:34vh}.panel{padding:14px}.two{grid-template-columns:1fr}.hero{align-items:flex-start;flex-direction:column}}
</style></head><body><header><strong>High Games Admin</strong><span class="pill" id="status">Carregando</span><div class="tabs"><button onclick="show('chat')">Conversas</button><button onclick="show('train')">Treinar</button><button onclick="show('settings')">IA</button></div></header><main><aside><div class="sideTitle">Conversas</div><div id="list"></div></aside><section class="panel" id="chat"></section><section class="panel hide" id="train"></section><section class="panel hide" id="settings"></section></main>
<script>
let state={conversations:[],training:[],settings:{}},current=null,active='chat',draft={tt:'',tc:'',testmsg:'',manual:'',sp:null,bk:null,mt:null,temp:null},dirty=false;
document.addEventListener('input',e=>{if(e.target&&['INPUT','TEXTAREA'].includes(e.target.tagName))dirty=true});
function captureDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el)draft[id]=el.value}}
function restoreDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el&&draft[id]!==null&&draft[id]!==undefined)el.value=draft[id]}}
async function load(opts={}){captureDraft();state=await(await fetch('/api/state')).json();renderList();if(opts.force||active==='chat')renderChat();if((opts.force||active==='train')&&!dirty)renderTrain();if((opts.force||active==='settings')&&!dirty)renderSettings();restoreDraft()}
function show(id){captureDraft();active=id;for(const el of document.querySelectorAll('section.panel'))el.classList.add('hide');document.getElementById(id).classList.remove('hide');if(id==='chat')renderChat();if(id==='train')renderTrain();if(id==='settings')renderSettings();restoreDraft()}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function renderList(){status.textContent=(state.conversations.length||0)+' conversas';list.innerHTML=state.conversations.map(c=>'<div class="row" onclick="current=\\''+c.contact+'\\';renderChat()"><b>'+c.contact+'</b><small>'+esc((c.messages.at(-1)||{}).text)+'</small></div>').join('')||'<div class="row">Sem conversas ainda</div>'}
function conv(){return state.conversations.find(c=>c.contact===current)||state.conversations[0]}
function renderChat(){const c=conv();if(!c){chat.innerHTML='<div class="hero"><div><h2>Conversas</h2><p class="muted">As novas mensagens aparecerão aqui.</p></div></div>';return}current=c.contact;chat.innerHTML='<div class="hero"><div><h2>'+c.contact+'</h2><p class="muted">'+(c.humanMode?'Atendimento humano ativo':'IA respondendo automaticamente')+'</p></div><button class="ghost" onclick="toggleHuman('+!c.humanMode+')">'+(c.humanMode?'Ativar IA':'Assumir humano')+'</button></div><div class="messages">'+c.messages.map(m=>'<div class="msg '+m.role+'"><b>'+m.role+'</b><br>'+esc(m.text)+'</div>').join('')+'</div><div class="card"><textarea id="manual" placeholder="Responder manualmente"></textarea><p><button onclick="sendManual()">Enviar resposta</button></p></div>'}
function renderTrain(){train.innerHTML='<div class="hero"><div><h2>Base de Treinamento</h2><p class="muted">Tudo salvo aqui entra no prompt do Gemini automaticamente na próxima mensagem.</p></div></div><div class="card grid"><input id="tt" placeholder="Titulo do treinamento"><textarea id="tc" placeholder="Exemplo: Se o cliente pedir God of War 2, explique compatibilidade e peca o modelo do celular antes de falar de pagamento."></textarea><button onclick="saveTraining()">Salvar treinamento</button></div><div class="card grid"><h3>Testar treinamento</h3><textarea id="testmsg" placeholder="Digite uma mensagem de cliente para testar sem enviar no WhatsApp"></textarea><button onclick="testReply()">Gerar resposta de teste</button><div class="result" id="testout">Resultado aparecerá aqui.</div></div>'+state.training.map(t=>'<div class="card"><b>'+esc(t.title)+'</b><p>'+esc(t.content)+'</p><button class="danger" onclick="deleteTraining(\\''+t.id+'\\')">Excluir</button></div>').join('')}
function renderSettings(){settings.innerHTML='<div class="hero"><div><h2>Configurar IA</h2><p class="muted">Ajustes aplicam imediatamente nas próximas respostas.</p></div></div><div class="card grid"><label>Prompt principal<textarea id="sp">'+esc(state.settings.systemPrompt)+'</textarea></label><label>Conhecimento do negocio<textarea id="bk">'+esc(state.settings.businessKnowledge)+'</textarea></label><div class="grid two"><label>Max tokens<input id="mt" value="'+(state.settings.maxOutputTokens||2048)+'"></label><label>Temperatura<input id="temp" value="'+(state.settings.temperature||0.45)+'"></label></div><button onclick="saveSettings()">Salvar IA</button></div>'}
async function saveTraining(){await fetch('/api/training',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:tt.value,content:tc.value})});draft.tt='';draft.tc='';dirty=false;await load({force:true})}
async function deleteTraining(id){dirty=false;await fetch('/api/training',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({id})});await load({force:true})}
async function testReply(){testout.textContent='Gerando...';const r=await fetch('/api/test-reply',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:testmsg.value})});const j=await r.json();testout.textContent=j.reply||JSON.stringify(j)}
async function saveSettings(){await fetch('/api/settings',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({systemPrompt:sp.value,businessKnowledge:bk.value,maxOutputTokens:Number(mt.value||2048),temperature:Number(temp.value||0.45)})});draft.sp=null;draft.bk=null;draft.mt=null;draft.temp=null;dirty=false;await load({force:true})}
async function toggleHuman(v){await fetch('/api/conversation',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,humanMode:v})});await load({force:true})}
async function sendManual(){await fetch('/api/send',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,text:manual.value})});draft.manual='';await load({force:true})}
load({force:true});setInterval(()=>load(),5000);
</script></body></html>`;
}
