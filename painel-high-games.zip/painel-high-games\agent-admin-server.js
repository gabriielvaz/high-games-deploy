import http from "node:http";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";

const port = Number(process.env.PORT || 3000);
const instance = process.env.INSTANCE_NAME || process.env.EVOLUTION_INSTANCE || "high-games";
const dataDir = process.env.DATA_DIR || "/data";
const stateFile = `${dataDir}/state.json`;
const humanSupportNumber = String(process.env.HUMAN_SUPPORT_NUMBER || "5511915705725").replace(/\D/g, "");
const promptPackVersion = "2026-05-21-prompt-engineer-v1";
const paymentAutomationVersion = "2026-05-28-payment-flow-v2";

const legacySystemPrompt =
  "Voce e o agente da High Games no WhatsApp. Seja claro, humano, consultivo e objetivo. Use historico e treinamento. Nao invente preco, link, prazo, garantia ou catalogo. Nao oriente pirataria, ROM ilegal, BIOS ilegal ou violacao de direitos autorais. Quando faltar informacao, faca uma pergunta objetiva.";

const legacyBusinessKnowledge =
  "A High Games atende clientes que querem jogar titulos compativeis com emulador de PS2 no celular. Ajude em compra, instalacao, configuracao, travamentos, controles, desempenho e suporte pos-venda. Pergunte jogo desejado e modelo do celular quando fizer sentido.";

const promptEngineerSystemPrompt = [
  "Voce e o agente de atendimento da High Games no WhatsApp.",
  "Seu papel e vender de forma consultiva, orientar instalacao, resolver duvidas tecnicas simples e chamar atendimento humano quando houver risco ou incerteza.",
  "Tom: brasileiro, amigavel, direto, confiante, jovem e natural. Nao pareca robotico.",
  "Sempre use o historico recente, a base fixa do negocio e os treinamentos cadastrados no painel.",
  "Faca uma pergunta objetiva quando faltar informacao importante.",
  "Nao invente preco, link, prazo, garantia, disponibilidade, catalogo, politica ou promessa tecnica.",
  "Nao oriente pirataria, download ilegal de ROMs, BIOS sem licenca ou violacao de direitos autorais.",
  "Quando houver duvida sobre licenca, pagamento, comprovante, reembolso, entrega de acesso ou caso sensivel, encaminhe para humano.",
  "PS2 e somente Android. PSP funciona em Android e iOS.",
  "Nao prometa compatibilidade perfeita. Recomende pelo menos 4 GB de RAM e 32 GB de memoria para melhor experiencia.",
  "Nao use markdown pesado. Responda em texto claro de WhatsApp, com frases curtas e completas."
].join("\n");

const promptEngineerBusinessKnowledge = [
  "Empresa: High Games.",
  "Oferta: jogos digitais classicos otimizados para celular, com pagamento unico, acesso por e-mail, tutorial de instalacao, guia de configuracao e suporte pos-venda.",
  "",
  "Catalogo inicial:",
  "- Jogos PS2 para Android: Resident Evil 4 Dublado, Bully Legendado PT-BR, GTA San Andreas Dublado, DBZ Budokai Tenkaichi 3 PT-BR, Bomba Patch 2026, Black Dublado, God of War 2 Dublado, NFS Underground 2 Mobile, Ben 10, GTA Vice City, Pack +100 jogos PS2 e Pack +500 jogos PS2.",
  "- Jogos PSP para Android e iOS: Pack +300 jogos PSP, GTA Liberty City, GTA Vice City, Ben 10, Midnight Club 3, NFS Most Wanted, God of War Ghost of Sparta, PES 2014 e FIFA 13.",
  "- Faixa de valores: jogos a partir de R$ 5,90. Muitos jogos individuais custam R$ 11,90. Packs custam R$ 24,90 ou R$ 34,90. Quando houver duvida, orientar o cliente a conferir no site oficial: https://loja.highgames.store.",
  "",
  "Como funciona:",
  "- Os jogos rodam por meio de emulador leve e acompanham tutorial.",
  "- Funcionam melhor em aparelhos com pelo menos 4 GB de RAM.",
  "- Celulares mais simples podem precisar do guia de configuracoes.",
  "- Jogos sao offline e de pagamento unico.",
  "- O cliente recebe links completos, tutorial de instalacao e guia de configuracao.",
  "",
  "Compra e entrega:",
  "- Preferencialmente conduzir para https://loja.highgames.store para compra e envio automatico por e-mail.",
  "- Se o cliente pagar e enviar comprovante pelo WhatsApp, pedir e-mail da compra e produto desejado.",
  "- Nao enviar links de acesso sem comprovante, pedido validado ou regra operacional configurada.",
  "- Se o cliente disser que nao recebeu o produto/acesso, nao chamar humano imediatamente. Primeiro pedir o nome exato do jogo ou pack e o e-mail usado na compra; tambem orientar verificar caixa de entrada, spam e lixo eletronico.",
  "- Nunca enviar acesso de um produto parecido ou escolhido por chute. So enviar acesso quando o produto estiver identificado com seguranca e houver comprovante/pedido validado.",
  "- Se houver mais de um produto possivel, pedir confirmacao do nome exato antes de liberar qualquer acesso.",
  "",
  "Suporte:",
  "- Se o cliente nao recebeu os acessos, orientar a verificar caixa de entrada, spam e lixo eletronico.",
  "- Para erro de instalacao, pedir nome do jogo, sistema do celular e print ou descricao do erro.",
  "- Para travamentos, pedir modelo do celular, RAM e jogo; orientar seguir guia de configuracoes.",
  "- Sobre BIOS no Drive: orientar tocar nos tres pontinhos ao lado da BIOS e apertar em baixar. Dizer para apenas baixar e continuar o tutorial; nao tentar abrir o arquivo diretamente.",
  "",
  "Regras obrigatorias:",
  "- Nao dizer que jogos de PS2 funcionam em iPhone.",
  "- Jogos de PSP funcionam em Android e iOS.",
  "- Nao prometer reembolso livre. Produto digital entregue nao tem reembolso, exceto produto defeituoso ou nao entregue conforme descrito.",
  "- Se a resposta exigir catalogo, preco, link ou politica nao configurada, seja transparente e chame humano."
].join("\n");

const promptEngineerTraining = [
  {
    id: "hg-venda-consultiva",
    title: "Venda consultiva High Games",
    content:
      "Quando o cliente demonstrar interesse em comprar, identificar primeiro o sistema do celular. Se quiser PS2, confirmar Android. Se for iPhone/iOS, direcionar para PSP. Explicar pagamento unico, jogos offline, entrega por e-mail e suporte. Conduzir para https://loja.highgames.store quando quiser finalizar."
  },
  {
    id: "hg-catalogo-e-precos",
    title: "Catalogo e precos",
    content:
      "Usar apenas o catalogo e as faixas cadastradas: jogos a partir de R$ 5,90, muitos individuais por R$ 11,90, packs por R$ 24,90 ou R$ 34,90. Se houver duvida, orientar consultar https://loja.highgames.store. Nunca inventar preco, jogo, promocao ou link."
  },
  {
    id: "hg-compatibilidade",
    title: "Compatibilidade Android, iOS, PS2 e PSP",
    content:
      "PS2 e somente Android. PSP funciona em Android e iOS. Para melhor experiencia, recomendar pelo menos 4 GB de RAM e 32 GB de memoria. Nao prometer compatibilidade perfeita; se o celular for fraco, explicar que o guia de configuracao pode ajudar."
  },
  {
    id: "hg-suporte-travamentos",
    title: "Suporte para travamentos",
    content:
      "Quando o cliente relatar travamento, lag, FPS baixo ou lentidao, pedir modelo do celular, RAM e nome do jogo. Orientar seguir o guia de configuracoes, reduzir resolucao, fechar apps em segundo plano e ajustar renderer quando fizer sentido, sem prometer resultado perfeito."
  },
  {
    id: "hg-entrega-acessos",
    title: "Entrega, comprovante e acessos",
    content:
      "Se o cliente disser que pagou, comprou, fez Pix ou pedir o acesso, pedir o comprovante em imagem/PDF e o nome exato do jogo ou pack. Quando o produto estiver cadastrado no painel e o comprovante for validado pelo fluxo automatico, o acesso pode ser liberado pela mensagem de entrega cadastrada. Se faltar produto, valor ou comprovante legivel, manter em revisao humana."
  },
  {
    id: "hg-bios-drive",
    title: "Duvida sobre BIOS no Drive",
    content:
      "Se o cliente nao conseguir baixar a BIOS pelo Drive, orientar tocar nos tres pontinhos ao lado do arquivo e apertar em baixar. Dizer para apenas baixar e continuar o tutorial. Nao tentar abrir o arquivo diretamente, pois ele nao abre mesmo."
  },
  {
    id: "hg-regras-legais",
    title: "Regras legais e seguranca",
    content:
      "Nao orientar pirataria, download ilegal de ROMs, BIOS sem licenca ou violacao de direitos autorais. Quando houver duvida sobre licenca, origem de arquivo, reembolso, disputa de pagamento ou promessa tecnica, encaminhar para atendimento humano."
  }
];

const defaults = {
  promptPackVersion,
  paymentAutomationVersion,
  settings: {
    aiEnabled: true,
    autoReleaseAccess: true,
    humanSupportAlerts: true,
    maxOutputTokens: 2048,
    temperature: 0.55,
    systemPrompt: promptEngineerSystemPrompt,
    businessKnowledge: promptEngineerBusinessKnowledge
  },
  training: promptEngineerTraining,
  products: [],
  paymentReviews: [],
  conversations: {}
};

let state = await loadState();

http.createServer(async (req, res) => {
  try {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const bodyText = Buffer.concat(chunks).toString("utf8");
    const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);

    if (url.pathname === "/health") {
      return sendJson(res, 200, {
        ok: true,
        aiProvider: selectedAiProvider(),
        ai: Boolean(process.env.GEMINI_API_KEY || process.env.GROK_API_KEY || process.env.XAI_API_KEY),
        model: selectedAiProvider() === "grok" ? (process.env.GROK_MODEL || "grok-4-fast") : (process.env.GEMINI_MODEL || "gemini-2.5-flash-lite")
      });
    }

    if (url.pathname === "/webhook") return handleWebhook(req, res, url, bodyText);

    if (url.pathname === "/admin") {
      if (!isAuthorized(req)) return unauthorized(res);
      return sendHtml(res, adminHtmlModern());
    }

    if (url.pathname.startsWith("/api/")) {
      if (!isAuthorized(req)) return unauthorized(res);
      return handleApi(req, res, url, bodyText);
    }

    return sendJson(res, 404, { ok: false });
  } catch (error) {
    console.error("Erro HTTP", error);
    return sendJson(res, 500, { ok: false, error: "internal_error" });
  }
}).listen(port, "0.0.0.0", () => console.log(`High Games agent admin listening on ${port}`));

async function handleWebhook(req, res, url, bodyText) {
  const token = url.searchParams.get("token") || req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (process.env.WEBHOOK_TOKEN && token !== process.env.WEBHOOK_TOKEN && process.env.STRICT_WEBHOOK_AUTH === "true") {
    return sendJson(res, 401, { ok: false });
  }
  if (process.env.WEBHOOK_TOKEN && token !== process.env.WEBHOOK_TOKEN) {
    console.warn("Webhook recebido sem token esperado; aceito em modo recuperacao.");
  }

  const dryRun = url.searchParams.get("dryRun") === "1";
  const payload = JSON.parse(bodyText || "{}");
  const messages = extractMessages(payload);
  console.log("Webhook recebido", JSON.stringify({ event: payload.event, messages: messages.map(m => ({ from: m.from, text: m.text, mediaType: m.media?.type || null })) }));

  for (const message of messages) {
    try {
      saveMessage(message.from, "cliente", message.text);
      const conversation = state.conversations[message.from];
      if (conversation?.humanMode) continue;

      let reply = message.media
        ? await handleIncomingMedia(message)
        : await handleIncomingText(message);

      const conversationAfterReply = ensureConversation(message.from);
      if (needsHumanSupport(message.text, reply, conversationAfterReply)) {
        reply = humanSupportReply();
        await notifyHumanSupport(message.from, message.text, reply);
      }

      saveMessage(message.from, "agente", reply);
      console.log("Enviando resposta", JSON.stringify({ to: message.from, reply }));
      if (!dryRun) await sendEvolutionText(message.from, reply);
    } catch (error) {
      console.error("Falha ao processar mensagem", {
        from: message.from,
        text: message.text,
        error: error?.message || String(error)
      });
      const reply = fallbackReply();
      saveMessage(message.from, "agente", reply);
      if (!dryRun) await sendEvolutionText(message.from, reply);
    }
  }

  if (!dryRun) await persist();
  return sendJson(res, 200, { ok: true, received: messages.length });
}

async function handleApi(req, res, url, bodyText) {
  if (url.pathname === "/api/state" && req.method === "GET") return sendJson(res, 200, publicState());

  if (url.pathname === "/api/settings" && req.method === "POST") {
    state.settings = { ...state.settings, ...JSON.parse(bodyText || "{}") };
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/training" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    if (!body.title || !body.content) return sendJson(res, 400, { ok: false });
    const item = { id: body.id || `${Date.now()}`, title: body.title, content: body.content };
    state.training = [item, ...state.training.filter(x => x.id !== item.id)];
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/training" && req.method === "DELETE") {
    const body = JSON.parse(bodyText || "{}");
    state.training = state.training.filter(x => x.id !== body.id);
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/products" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    if (!body.name || !body.accessMessage) return sendJson(res, 400, { ok: false });
    const item = {
      id: body.id || `${Date.now()}`,
      name: String(body.name || "").trim(),
      keywords: String(body.keywords || body.name || "").split(",").map(x => x.trim()).filter(Boolean),
      price: String(body.price || "").trim(),
      accessMessage: String(body.accessMessage || "").trim(),
      enabled: body.enabled !== false
    };
    state.products = [item, ...state.products.filter(x => x.id !== item.id)];
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/products" && req.method === "DELETE") {
    const body = JSON.parse(bodyText || "{}");
    state.products = state.products.filter(x => x.id !== body.id);
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/payment-review" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    const review = state.paymentReviews.find(x => x.id === body.id);
    if (!review) return sendJson(res, 404, { ok: false });
    if (body.action === "approve") {
      const product = state.products.find(x => x.id === (body.productId || review.productId));
      if (!product) return sendJson(res, 400, { ok: false, error: "product_not_found" });
      review.status = "approved";
      review.productId = product.id;
      review.productName = product.name;
      review.reviewedAt = new Date().toISOString();
      const text = accessMessageFor(product);
      saveMessage(review.contact, "humano", text);
      await sendEvolutionText(review.contact, text);
    } else if (body.action === "reject") {
      review.status = "rejected";
      review.reviewedAt = new Date().toISOString();
    }
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/test-reply" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    const contact = body.contact || "__training_test__";
    if (body.message) saveMessage(contact, "cliente", body.message);
    const reply = await generateAiReply(contact, body.message || "Oi, quero comprar");
    if (body.message) saveMessage(contact, "agente", reply);
    await persist();
    return sendJson(res, 200, { ok: true, reply });
  }

  if (url.pathname === "/api/conversation" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    const c = ensureConversation(body.contact);
    if (typeof body.humanMode === "boolean") c.humanMode = body.humanMode;
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  if (url.pathname === "/api/send" && req.method === "POST") {
    const body = JSON.parse(bodyText || "{}");
    saveMessage(body.contact, "humano", body.text);
    await sendEvolutionText(body.contact, body.text);
    await persist();
    return sendJson(res, 200, { ok: true });
  }

  return sendJson(res, 404, { ok: false });
}

function extractMessages(payload) {
  if (Array.isArray(payload?.messages)) {
    return payload.messages
      .filter(item => item && !item.fromMe)
      .map(item => ({
        from: jidToRecipient(item.from || item.remoteJid || item.sender || ""),
        text: String(item.text || item.message || item.body || "").trim(),
        media: item.media || null,
        raw: item
      }))
      .filter(item => item.from && (item.text || item.media));
  }

  const raw = Array.isArray(payload?.data)
    ? payload.data
    : Array.isArray(payload?.data?.messages)
      ? payload.data.messages
      : Array.isArray(payload?.data?.messagesUpsert)
        ? payload.data.messagesUpsert
        : [payload?.data || payload];
  const out = [];
  for (const item of raw) {
    const key = item?.key;
    if (!key || key.fromMe) continue;
    const remoteJid = firstTruthy(
      item.senderPn,
      item.sender,
      item.participantPn,
      item.key?.senderPn,
      item.key?.remoteJidAlt,
      item.key?.participantPn,
      item.key?.participantAlt,
      item.key?.participant,
      item.key?.remoteJid,
      item.remoteJid,
      payload.sender
    );
    if (remoteJid.includes("@g.us")) continue;
    const media = extractMedia(item);
    const text = (item.message?.conversation || item.message?.extendedTextMessage?.text || item.message?.imageMessage?.caption || item.message?.videoMessage?.caption || item.message?.documentMessage?.caption || "").trim();
    if (text || media) out.push({
      from: jidToRecipient(remoteJid),
      text: text || `[${media.type} recebida]`,
      media,
      raw: item
    });
  }
  return out;
}

function firstTruthy(...values) {
  return values.find(value => value) || "";
}

function extractMedia(item) {
  const msg = item?.message || {};
  const mediaMessage = msg.imageMessage || msg.documentMessage || msg.videoMessage;
  if (!mediaMessage) return null;
  return {
    raw: item,
    type: msg.imageMessage ? "imagem" : msg.documentMessage ? "documento" : "video",
    messageKind: msg.imageMessage ? "imageMessage" : msg.documentMessage ? "documentMessage" : "videoMessage",
    id: item?.key?.id || item?.id || "",
    key: item?.key || {},
    mimetype: mediaMessage.mimetype || "",
    fileName: mediaMessage.fileName || "",
    caption: mediaMessage.caption || "",
    base64: mediaMessage.base64 || item.base64 || ""
  };
}

async function handleIncomingText(message) {
  const completed = await maybeCompletePendingReview(message.from, message.text);
  if (completed) return completed;

  if (isDeliveryIssue(message.text)) {
    return handleDeliveryIssue(message);
  }

  if (isPaymentIntent(message.text)) {
    const product = findProductForContact(message.from, message.text);
    if (product) {
      return "Perfeito. Para eu liberar o acesso do " + product.name + ", me envie o comprovante de pagamento em imagem ou PDF aqui no WhatsApp.";
    }
    return "Perfeito. Para eu liberar o acesso, me envie o comprovante de pagamento em imagem ou PDF e me diga o nome exato do jogo ou pack comprado.";
  }

  if (!state.settings.aiEnabled) {
    return "Recebi sua mensagem. Uma pessoa da equipe vai continuar o atendimento.";
  }

  return generateAiReply(message.from, message.text);
}

async function handleIncomingMedia(message) {
  const product = findProductForContact(message.from, message.text);
  const mediaData = await getMediaBase64(message.media);
  const analysis = mediaData.base64 ? await analyzeReceiptWithGemini(mediaData) : null;
  const verdict = buildPaymentVerdict(analysis, product);
  const review = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    contact: message.from,
    status: verdict.canAutoRelease && state.settings.autoReleaseAccess ? "approved" : "pending",
    productId: product?.id || "",
    productName: product?.name || "",
    customerText: message.text,
    mediaType: message.media?.type || "",
    amount: analysis?.valor || "",
    transactionId: analysis?.id_transacao || "",
    looksValid: verdict.looksValid,
    priceOk: verdict.priceOk,
    confidence: analysis?.confianca || "baixa",
    summary: verdict.summary,
    createdAt: new Date().toISOString(),
    reviewedAt: verdict.canAutoRelease && state.settings.autoReleaseAccess ? new Date().toISOString() : ""
  };
  state.paymentReviews = [review, ...(state.paymentReviews || [])].slice(0, 200);

  if (review.status === "approved" && product) {
    return accessMessageFor(product);
  }

  if (!product) {
    return "Recebi seu comprovante. Para eu localizar o acesso correto, me diga o nome exato do jogo ou pack que voce comprou.";
  }

  if (!mediaData.base64) {
    return "Recebi o comprovante do " + product.name + ". Nao consegui ler a imagem automaticamente agora, entao deixei para revisao humana e a equipe ja consegue aprovar pelo painel.";
  }

  return "Recebi o comprovante do " + product.name + ". Vou validar o pagamento e liberar o acesso assim que estiver tudo certo.";
}

function handleDeliveryIssue(message) {
  const product = findSingleProduct(message.text);
  if (product) {
    return [
      "Entendi. Vou te ajudar com o acesso do " + product.name + ".",
      "Primeiro confira se o e-mail nao caiu na caixa de entrada, spam ou lixo eletronico.",
      "Para eu localizar sem enviar acesso errado, me envie o e-mail usado na compra e, se tiver, o comprovante ou print do pedido."
    ].join(" ");
  }

  return [
    "Entendi, vou te ajudar a localizar seu acesso.",
    "Me diga o nome exato do jogo ou pack comprado e o e-mail usado na compra.",
    "Se tiver comprovante ou print do pedido, envie tambem para eu conferir mais rapido."
  ].join(" ");
}

async function getMediaBase64(media) {
  if (!media) return { base64: "", mimetype: "" };
  if (media.base64) return { base64: cleanBase64(media.base64), mimetype: media.mimetype || "image/jpeg" };
  const baseUrl = process.env.EVOLUTION_BASE_URL || "http://evolution-api:8080";
  try {
    const response = await fetch(`${baseUrl}/chat/getBase64FromMediaMessage/${instance}`, {
      method: "POST",
      headers: { apikey: process.env.EVOLUTION_API_KEY, "content-type": "application/json" },
      body: JSON.stringify({ message: media.raw || { key: media.key }, convertToMp4: false })
    });
    const text = await response.text();
    if (!response.ok) {
      console.error("getBase64 failed", response.status, text);
      return { base64: "", mimetype: media.mimetype || "" };
    }
    const data = parseMaybeJson(text);
    const base64 = cleanBase64(data?.base64 || data?.data || data?.response?.base64 || text);
    return { base64, mimetype: data?.mimetype || media.mimetype || "image/jpeg" };
  } catch (error) {
    console.error("Falha getBase64", error);
    return { base64: "", mimetype: media.mimetype || "" };
  }
}

async function analyzeReceiptWithGemini(mediaData) {
  if (!process.env.GEMINI_API_KEY) return null;
  const model = process.env.GEMINI_VISION_MODEL || process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
  const prompt = [
    "Analise esta imagem ou documento enviado no WhatsApp.",
    "Diga se parece ser comprovante de pagamento.",
    "Extraia valor, data, pagador, recebedor e id da transacao quando existirem.",
    "Responda somente em JSON valido, sem markdown, no formato:",
    '{"parece_comprovante":true,"valor":"11.90","data":"","pagador":"","recebedor":"","id_transacao":"","confianca":"alta","observacoes":""}'
  ].join("\n");
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{
          role: "user",
          parts: [
            { text: prompt },
            { inline_data: { mime_type: mediaData.mimetype || "image/jpeg", data: mediaData.base64 } }
          ]
        }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 600 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Erro Gemini comprovante", response.status, JSON.stringify(data));
      return null;
    }
    const text = String(data.candidates?.[0]?.content?.parts?.[0]?.text || "").trim();
    return parseReceiptJson(text);
  } catch (error) {
    console.error("Falha Gemini comprovante", error);
    return null;
  }
}

function buildPaymentVerdict(analysis, product) {
  if (!analysis) return { canAutoRelease: false, looksValid: false, priceOk: false, summary: "Nao foi possivel analisar o comprovante automaticamente." };
  const looksValid = analysis.parece_comprovante === true || String(analysis.parece_comprovante).toLowerCase() === "true";
  const confidence = String(analysis.confianca || "").toLowerCase();
  const confidenceOk = confidence === "alta" || confidence === "media";
  const priceOk = product ? priceMatches(product.price, analysis.valor) : false;
  const canAutoRelease = Boolean(looksValid && confidenceOk && product && priceOk);
  return {
    canAutoRelease,
    looksValid,
    priceOk,
    summary: [
      looksValid ? "Parece comprovante." : "Nao parece comprovante com seguranca.",
      product ? `Produto: ${product.name}.` : "Produto nao identificado.",
      analysis.valor ? `Valor lido: ${analysis.valor}.` : "Valor nao identificado.",
      product?.price ? `Valor esperado: ${product.price}.` : "",
      priceOk ? "Valor compativel." : "Valor precisa de revisao."
    ].filter(Boolean).join(" ")
  };
}

function findProductForContact(contact, text) {
  const current = findSingleProduct(text);
  if (current) return current;

  const c = ensureConversation(contact);
  const recent = c.messages
    .slice(-6)
    .filter(m => m.role === "cliente" || m.role === "client" || m.role === "customer")
    .map(m => m.text)
    .join(" ");
  return findSingleProduct(recent);
}

async function maybeCompletePendingReview(contact, text) {
  const product = findSingleProduct(text);
  if (!product) return "";
  const review = (state.paymentReviews || []).find(item => item.contact === contact && item.status === "pending" && !item.productId);
  if (!review) return "";

  review.productId = product.id;
  review.productName = product.name;
  review.priceOk = priceMatches(product.price, review.amount);
  review.summary = [
    review.summary || "Comprovante recebido.",
    `Produto informado depois: ${product.name}.`,
    review.priceOk ? "Valor compativel." : "Valor precisa de revisao."
  ].join(" ");

  const confidenceOk = ["alta", "media"].includes(String(review.confidence || "").toLowerCase());
  if (state.settings.autoReleaseAccess && review.looksValid && confidenceOk && review.priceOk) {
    review.status = "approved";
    review.reviewedAt = new Date().toISOString();
    return accessMessageFor(product);
  }

  return "Obrigado. Localizei o produto " + product.name + " e deixei seu comprovante em validacao. Assim que estiver tudo certo, o acesso sera liberado.";
}

function isPaymentIntent(text) {
  const normalized = normalizeText(text);
  return [
    "paguei",
    "pagamento",
    "comprovante",
    "pix",
    "transferi",
    "comprei",
    "ja fiz",
    "ja paguei",
    "mande o acesso",
    "manda o acesso",
    "enviar acesso",
    "liberar acesso"
  ].some(term => normalized.includes(term));
}

function isDeliveryIssue(text) {
  const normalized = normalizeText(text);
  return [
    "nao recebi",
    "nao chegou",
    "acesso nao chegou",
    "link nao chegou",
    "produto nao chegou",
    "jogo nao chegou",
    "cade meu acesso",
    "cadê meu acesso",
    "cade o acesso",
    "cadê o acesso",
    "cade meu jogo",
    "cadê meu jogo",
    "comprei e nao recebi",
    "paguei e nao recebi",
    "paguei mas nao recebi",
    "nao achei no email",
    "nao achei no e-mail",
    "nao chegou no email",
    "nao chegou no e-mail",
    "spam",
    "lixo eletronico",
    "lixo eletrônico"
  ].some(term => normalized.includes(normalizeText(term)));
}

function findProduct(text) {
  return findSingleProduct(text);
}

function findSingleProduct(text) {
  const matches = findProductMatches(text);
  if (matches.length === 0) return null;
  if (matches.length === 1) return matches[0].product;

  const [first, second] = matches;
  return first.score >= second.score + 10 ? first.product : null;
}

function findProductMatches(text) {
  const haystack = ` ${normalizeText(text)} `;
  if (!haystack.trim()) return [];

  return (state.products || []).filter(Boolean).map(product => {
    if (product.enabled === false) return false;
    const productName = normalizeText(product.name);
    const terms = [product.name, ...keywordList(product.keywords)]
      .map(normalizeText)
      .filter(term => term && term.length >= 3);

    let score = 0;
    for (const term of terms) {
      if (!haystack.includes(term)) continue;
      score += term === productName ? 120 : Math.min(term.length, 40);
    }

    return score > 0 ? { product, score } : null;
  })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score);
}

function accessMessageFor(product) {
  return String(product.accessMessage || "").trim();
}

function keywordList(value) {
  if (Array.isArray(value)) return value.map(item => String(item || "").trim()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map(item => item.trim()).filter(Boolean);
  return [];
}

function priceMatches(expected, actual) {
  const a = parseMoney(expected);
  const b = parseMoney(actual);
  if (!a || !b) return false;
  return Math.abs(a - b) <= 0.2;
}

function parseMoney(value) {
  let clean = String(value || "").replace(/[^\d,.]/g, "");
  if (clean.includes(",") && clean.includes(".")) {
    clean = clean.lastIndexOf(",") > clean.lastIndexOf(".")
      ? clean.replace(/\./g, "").replace(",", ".")
      : clean.replace(/,/g, "");
  } else if (clean.includes(",")) {
    clean = clean.replace(",", ".");
  } else if (clean.includes(".")) {
    const parts = clean.split(".");
    clean = parts.at(-1)?.length <= 2 ? clean : clean.replace(/\./g, "");
  }
  const number = Number(clean);
  return Number.isFinite(number) ? number : 0;
}

function normalizeText(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function cleanBase64(value) {
  return String(value || "").replace(/^data:[^;]+;base64,/, "").replace(/\s+/g, "");
}

function parseMaybeJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

function parseReceiptJson(text) {
  const clean = String(text || "").replace(/```json|```/g, "").trim();
  const match = clean.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try { return JSON.parse(match[0]); } catch { return null; }
}

async function generateAiReply(contact, input) {
  const c = ensureConversation(contact);
  const history = c.messages.slice(-12).map(m => `${m.role}: ${m.text}`).join("\n");
  const training = state.training.map(t => `Titulo: ${t.title}\nConteudo: ${t.content}`).join("\n\n");
  const products = productCatalogForPrompt();
  const prompt = [
    state.settings.systemPrompt,
    "",
    "Base fixa do negocio:",
    state.settings.businessKnowledge,
    "",
    "Produtos cadastrados no painel:",
    products || "Nenhum produto cadastrado no painel.",
    "",
    "Fluxo obrigatorio de comprovante:",
    "- Se o cliente disser que pagou, comprou, fez Pix ou pedir acesso, solicite comprovante em imagem/PDF e o nome exato do jogo ou pack.",
    "- Nao envie links de acesso por resposta comum da IA.",
    "- Os links de acesso so podem sair pelo fluxo automatico de comprovante aprovado ou por aprovacao humana no painel.",
    "- Se o cliente ja enviou comprovante mas faltou nome do produto, peca apenas o nome do jogo ou pack.",
    "",
    "Base de treinamento cadastrada:",
    training || "Nenhum treinamento cadastrado.",
    "",
    "Historico recente da conversa:",
    history || "Sem historico anterior.",
    "",
    `Mensagem atual do cliente: ${input}`,
    "",
    "Responda de forma completa, finalize a frase e nao corte no meio. Seja breve quando possivel, mas entregue uma resposta inteira. Nao use markdown."
  ].join("\n");

  const primary = selectedAiProvider();
  const providers = primary === "grok" ? ["grok", "gemini"] : ["gemini", "grok"];
  for (const provider of providers) {
    if (provider === "grok" && (process.env.GROK_API_KEY || process.env.XAI_API_KEY)) {
      const answer = await callGrok(prompt);
      if (answer) return answer;
    }
    if (provider === "gemini" && process.env.GEMINI_API_KEY) {
      const answer = await callGemini(prompt);
      if (answer) return answer;
    }
  }

  return fallbackReply();
}

function productCatalogForPrompt() {
  return (state.products || [])
    .filter(Boolean)
    .filter(product => product.enabled !== false)
    .map(product => {
      const keywords = keywordList(product.keywords).join(", ");
      return `Produto: ${product.name}; preco esperado: ${product.price || "nao informado"}; palavras-chave: ${keywords || product.name}`;
    })
    .join("\n");
}

function selectedAiProvider() {
  return String(process.env.AI_PROVIDER || "gemini").toLowerCase().trim();
}

async function callGemini(prompt) {
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: Number(state.settings.temperature || 0.55),
          maxOutputTokens: Number(state.settings.maxOutputTokens || 900)
        }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Erro Gemini", response.status, JSON.stringify(data));
      return "";
    }
    const candidate = data.candidates?.[0] || {};
    const answer = String(candidate.content?.parts?.[0]?.text || "").replace(/\s+/g, " ").trim();
    console.log("Gemini respondeu", JSON.stringify({ finishReason: candidate.finishReason || null, preview: answer.slice(0, 180) }));
    return answer;
  } catch (error) {
    console.error("Falha Gemini", error);
    return "";
  }
}

async function callGrok(prompt) {
  const model = process.env.GROK_MODEL || "grok-4-fast";
  const apiKey = process.env.GROK_API_KEY || process.env.XAI_API_KEY;
  try {
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiKey}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: prompt }],
        temperature: Number(state.settings.temperature || 0.55),
        max_tokens: Number(state.settings.maxOutputTokens || 900)
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Erro Grok", response.status, JSON.stringify(data));
      return "";
    }
    const answer = String(data.choices?.[0]?.message?.content || "").replace(/\s+/g, " ").trim();
    console.log("Grok respondeu", JSON.stringify({ finishReason: data.choices?.[0]?.finish_reason || null, preview: answer.slice(0, 180) }));
    return answer;
  } catch (error) {
    console.error("Falha Grok", error);
    return "";
  }
}

async function sendEvolutionText(number, text) {
  const baseUrl = process.env.EVOLUTION_BASE_URL || "http://evolution-api:8080";
  try {
    const response = await fetch(`${baseUrl}/message/sendText/${instance}`, {
      method: "POST",
      headers: { apikey: process.env.EVOLUTION_API_KEY, "content-type": "application/json" },
      body: JSON.stringify({ number, text, delay: 900, linkPreview: false })
    });
    if (!response.ok) {
      console.error("sendText failed", response.status, await response.text());
      return false;
    }
    return true;
  } catch (error) {
    console.error("sendText exception", error?.message || String(error));
    return false;
  }
}

function needsHumanSupport(customerText, agentReply, conversation) {
  if (!state.settings.humanSupportAlerts) return false;
  if (conversation?.humanMode) return false;
  const customer = normalizeText(customerText || "");
  const reply = normalizeText(agentReply || "");

  const explicitHumanTerms = [
    "quero falar com humano",
    "quero falar com atendente",
    "falar com atendente",
    "falar com suporte",
    "chamar suporte",
    "chamar humano",
    "atendimento humano",
    "me chama no suporte",
    "me passa para uma pessoa",
    "me passa para alguem"
  ];

  const criticalTerms = [
    "reembolso",
    "estorno",
    "chargeback",
    "processo",
    "procon",
    "advogado",
    "golpe",
    "fraude",
    "denunciar",
    "vou denunciar",
    "ameaca",
    "ameacando"
  ];

  const agentAskedForHuman = [
    "vou chamar um dos nossos especialistas",
    "vou chamar um especialista",
    "atendimento humano vai assumir"
  ];

  return explicitHumanTerms.some(term => customer.includes(term))
    || criticalTerms.some(term => customer.includes(term))
    || agentAskedForHuman.some(term => reply.includes(term));
}

function humanSupportReply() {
  return "Vou chamar um dos nossos especialistas para te ajudar melhor. Ele vai assumir seu atendimento assim que possivel.";
}

async function notifyHumanSupport(contact, customerText, agentReply) {
  const c = ensureConversation(contact);
  const now = Date.now();
  if (c.lastHumanAlertAt && now - Date.parse(c.lastHumanAlertAt) < 30 * 60 * 1000) return;
  c.lastHumanAlertAt = new Date(now).toISOString();
  c.humanMode = true;

  const recent = c.messages.slice(-5).map(m => `${roleLabelForAlert(m.role)}: ${m.text}`).join("\n");
  const alert = [
    "ALERTA HIGH GAMES",
    "Cliente precisa de suporte humano.",
    "",
    `Contato: ${contact}`,
    `Ultima mensagem: ${customerText || "Nao informado"}`,
    "",
    "Resumo recente:",
    recent || "Sem historico recente.",
    "",
    `Resposta do agente: ${agentReply || humanSupportReply()}`,
    "",
    "Acesse o painel para assumir o atendimento."
  ].join("\n");
  await sendEvolutionText(humanSupportNumber, alert);
}

function roleLabelForAlert(role) {
  return { cliente: "Cliente", client: "Cliente", agente: "IA", agent: "IA", humano: "Humano", human: "Humano" }[role] || role || "Mensagem";
}

function saveMessage(contact, role, text) {
  const c = ensureConversation(contact);
  c.updatedAt = new Date().toISOString();
  c.messages.push({ role, text, at: c.updatedAt });
  c.messages = c.messages.slice(-80);
}

function ensureConversation(contact) {
  state.conversations[contact] ||= { contact, humanMode: false, updatedAt: new Date().toISOString(), messages: [] };
  return state.conversations[contact];
}

function publicState() {
  return {
    settings: state.settings,
    training: state.training,
    products: state.products || [],
    paymentReviews: state.paymentReviews || [],
    conversations: Object.values(state.conversations || {}).sort((a, b) => String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")))
  };
}

async function loadState() {
  await mkdir(dataDir, { recursive: true });
  const loaded = existsSync(stateFile) ? JSON.parse(await readFile(stateFile, "utf8")) : {};
  return mergePromptEngineerDefaults(loaded);
}

async function persist() { await writeFile(stateFile, JSON.stringify(state, null, 2)); }
function fallbackReply() { return "Estou com uma instabilidade na IA agora, mas consigo te ajudar. Me diga qual jogo voce quer jogar e qual e o modelo do seu celular."; }
function jidToRecipient(v) { const jid = String(v || ""); if (jid.endsWith("@lid")) return jid; return jid.split("@")[0].replace(/\D/g, ""); }

function mergePromptEngineerDefaults(loaded) {
  const shouldApplyPromptPack = loaded.promptPackVersion !== promptPackVersion;
  const shouldApplyPaymentAutomation = loaded.paymentAutomationVersion !== paymentAutomationVersion;
  const merged = {
    ...structuredClone(defaults),
    ...loaded,
    settings: {
      ...structuredClone(defaults.settings),
      ...(loaded.settings || {})
    },
    products: Array.isArray(loaded.products) ? loaded.products : [],
    paymentReviews: Array.isArray(loaded.paymentReviews) ? loaded.paymentReviews : [],
    conversations: loaded.conversations || {}
  };

  if (shouldApplyPaymentAutomation) {
    merged.settings.autoReleaseAccess = true;
  }

  if (shouldApplyPromptPack || !merged.settings.systemPrompt || merged.settings.systemPrompt === legacySystemPrompt) {
    merged.settings.systemPrompt = promptEngineerSystemPrompt;
  }

  if (shouldApplyPromptPack || !merged.settings.businessKnowledge || merged.settings.businessKnowledge === legacyBusinessKnowledge) {
    merged.settings.businessKnowledge = promptEngineerBusinessKnowledge;
  }

  const existing = Array.isArray(loaded.training) ? loaded.training : [];
  const oldStarterIds = new Set(["venda", "suporte"]);
  const customTraining = existing.filter((item) => item?.id && !oldStarterIds.has(item.id));
  const byId = new Map(customTraining.map((item) => [item.id, item]));

  for (const item of promptEngineerTraining) {
    byId.set(item.id, item);
  }

  merged.training = [...promptEngineerTraining, ...customTraining.filter((item) => !promptEngineerTraining.some((base) => base.id === item.id))];
  merged.promptPackVersion = promptPackVersion;
  merged.paymentAutomationVersion = paymentAutomationVersion;
  return merged;
}

function isAuthorized(req) {
  if (!process.env.ADMIN_PASSWORD) return true;
  const auth = req.headers.authorization || "";
  if (!auth.startsWith("Basic ")) return false;
  const [, pass] = Buffer.from(auth.slice(6), "base64").toString("utf8").split(":");
  return pass === process.env.ADMIN_PASSWORD;
}

function unauthorized(res) { res.writeHead(401, { "www-authenticate": 'Basic realm="High Games Admin"' }); res.end("Login necessario"); }
function sendJson(res, status, body) { res.writeHead(status, { "content-type": "application/json; charset=utf-8" }); res.end(JSON.stringify(body)); }
function sendHtml(res, html) { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(html); }

function adminHtml() {
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>High Games Admin</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;background:#f4f5f7;color:#14171f}header{position:sticky;top:0;z-index:2;background:#111827;color:white;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;box-shadow:0 2px 14px #0002}header strong{font-size:18px}.pill{border:1px solid #334155;background:#1f2937;color:#dbeafe;padding:6px 9px;border-radius:999px;font-size:12px}main{display:grid;grid-template-columns:360px 1fr;min-height:calc(100vh - 60px)}aside{border-right:1px solid #e5e7eb;background:#fff;overflow:auto}.sideTitle{padding:16px 16px 8px;color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.row{padding:14px 16px;border-bottom:1px solid #eef0f3;cursor:pointer}.row:hover{background:#f8fafc}.row b{display:block;margin-bottom:5px}.row small{display:block;color:#6b7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}button,input,textarea{font:inherit}button{border:0;background:#111827;color:white;padding:10px 13px;border-radius:8px;cursor:pointer}button:hover{filter:brightness(1.08)}.ghost{background:#e5e7eb;color:#111827}.danger{background:#b91c1c}.panel{padding:20px;max-width:1120px}.hero{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}.card{background:white;border:1px solid #e5e7eb;border-radius:8px;padding:16px;margin-bottom:16px;box-shadow:0 1px 4px #0000000d}.messages{display:flex;flex-direction:column;gap:10px;margin-bottom:16px}.msg{max-width:820px;padding:11px 13px;border-radius:8px;background:white;border:1px solid #e5e7eb;line-height:1.4}.cliente{align-self:flex-start}.agente{align-self:flex-end;background:#e8f2ff;border-color:#bfdbfe}.humano{align-self:flex-end;background:#e9f9ef;border-color:#bbf7d0}textarea,input{width:100%;border:1px solid #d1d5db;border-radius:8px;padding:11px;background:white}textarea{min-height:112px;resize:vertical}.grid{display:grid;gap:12px}.two{grid-template-columns:1fr 1fr}.tabs{display:flex;gap:8px;flex-wrap:wrap}.tabs button{background:#374151}.hide{display:none}.muted{color:#6b7280}.toolbar{display:flex;gap:8px;flex-wrap:wrap}.result{white-space:pre-wrap;background:#0f172a;color:#e5e7eb;border-radius:8px;padding:12px;min-height:48px}@media(max-width:840px){main{grid-template-columns:1fr}aside{max-height:34vh}.panel{padding:14px}.two{grid-template-columns:1fr}.hero{align-items:flex-start;flex-direction:column}}
</style></head><body><header><strong>High Games Admin</strong><span class="pill" id="status">Carregando</span><div class="tabs"><button onclick="show('chat')">Conversas</button><button onclick="show('train')">Treinar</button><button onclick="show('settings')">IA</button></div></header><main><aside><div class="sideTitle">Conversas</div><div id="list"></div></aside><section class="panel" id="chat"></section><section class="panel hide" id="train"></section><section class="panel hide" id="settings"></section></main>
<script>
let state={conversations:[],training:[],settings:{}},current=null,active='chat',draft={tt:'',tc:'',testmsg:'',manual:'',sp:null,bk:null,mt:null,temp:null},dirty=false;
document.addEventListener('input',e=>{if(e.target&&['INPUT','TEXTAREA'].includes(e.target.tagName))dirty=true});
function captureDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el)draft[id]=el.value}}
function restoreDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el&&draft[id]!==null&&draft[id]!==undefined)el.value=draft[id]}}
async function load(opts={}){captureDraft();state=await(await fetch('/api/state')).json();renderList();if(opts.force||active==='chat')renderChat();if((opts.force||active==='train')&&!dirty)renderTrain();if((opts.force||active==='settings')&&!dirty)renderSettings();restoreDraft()}
function show(id){captureDraft();active=id;for(const el of document.querySelectorAll('section.panel'))el.classList.add('hide');document.getElementById(id).classList.remove('hide');if(id==='chat')renderChat();if(id==='train')renderTrain();if(id==='settings')renderSettings();restoreDraft()}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function renderList(){status.textContent=(state.conversations.length||0)+' conversas';list.innerHTML=state.conversations.map(c=>'<div class="row" onclick="current=\\''+c.contact+'\\';renderChat()"><b>'+c.contact+'</b><small>'+esc((c.messages.at(-1)||{}).text)+'</small></div>').join('')||'<div class="row">Sem conversas ainda</div>'}
function conv(){return state.conversations.find(c=>c.contact===current)||state.conversations[0]}
function renderChat(){const c=conv();if(!c){chat.innerHTML='<div class="hero"><div><h2>Conversas</h2><p class="muted">As novas mensagens aparecerão aqui.</p></div></div>';return}current=c.contact;chat.innerHTML='<div class="hero"><div><h2>'+c.contact+'</h2><p class="muted">'+(c.humanMode?'Atendimento humano ativo':'IA respondendo automaticamente')+'</p></div><button class="ghost" onclick="toggleHuman('+!c.humanMode+')">'+(c.humanMode?'Ativar IA':'Assumir humano')+'</button></div><div class="messages">'+c.messages.map(m=>'<div class="msg '+m.role+'"><b>'+m.role+'</b><br>'+esc(m.text)+'</div>').join('')+'</div><div class="card"><textarea id="manual" placeholder="Responder manualmente"></textarea><p><button onclick="sendManual()">Enviar resposta</button></p></div>'}
function renderTrain(){train.innerHTML='<div class="hero"><div><h2>Base de Treinamento</h2><p class="muted">Tudo salvo aqui entra no prompt do Gemini automaticamente na próxima mensagem.</p></div></div><div class="card grid"><input id="tt" placeholder="Titulo do treinamento"><textarea id="tc" placeholder="Exemplo: Se o cliente pedir God of War 2, explique compatibilidade e peca o modelo do celular antes de falar de pagamento."></textarea><button onclick="saveTraining()">Salvar treinamento</button></div><div class="card grid"><h3>Testar treinamento</h3><textarea id="testmsg" placeholder="Digite uma mensagem de cliente para testar sem enviar no WhatsApp"></textarea><button onclick="testReply()">Gerar resposta de teste</button><div class="result" id="testout">Resultado aparecerá aqui.</div></div>'+state.training.map(t=>'<div class="card"><b>'+esc(t.title)+'</b><p>'+esc(t.content)+'</p><button class="danger" onclick="deleteTraining(\\''+t.id+'\\')">Excluir</button></div>').join('')}
function renderSettings(){settings.innerHTML='<div class="hero"><div><h2>Configurar IA</h2><p class="muted">Ajustes aplicam imediatamente nas próximas respostas.</p></div></div><div class="card grid"><label>Prompt principal<textarea id="sp">'+esc(state.settings.systemPrompt)+'</textarea></label><label>Conhecimento do negocio<textarea id="bk">'+esc(state.settings.businessKnowledge)+'</textarea></label><div class="grid two"><label>Max tokens<input id="mt" value="'+(state.settings.maxOutputTokens||2048)+'"></label><label>Temperatura<input id="temp" value="'+(state.settings.temperature||0.45)+'"></label></div><button onclick="saveSettings()">Salvar IA</button></div>'}
async function saveTraining(){await fetch('/api/training',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:tt.value,content:tc.value})});draft.tt='';draft.tc='';dirty=false;await load({force:true})}
async function deleteTraining(id){dirty=false;await fetch('/api/training',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({id})});await load({force:true})}
async function testReply(){testout.textContent='Gerando...';const r=await fetch('/api/test-reply',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:testmsg.value})});const j=await r.json();testout.textContent=j.reply||JSON.stringify(j)}
async function saveSettings(){await fetch('/api/settings',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({systemPrompt:sp.value,businessKnowledge:bk.value,maxOutputTokens:Number(mt.value||2048),temperature:Number(temp.value||0.45)})});draft.sp=null;draft.bk=null;draft.mt=null;draft.temp=null;dirty=false;await load({force:true})}
async function toggleHuman(v){await fetch('/api/conversation',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,humanMode:v})});await load({force:true})}
async function sendManual(){await fetch('/api/send',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,text:manual.value})});draft.manual='';await load({force:true})}
load({force:true});setInterval(()=>load(),5000);
</script></body></html>`;
}

function adminHtmlNew() {
  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>High Games Admin</title>
<style>
:root{--bg:#f6f4ef;--surface:#fff;--ink:#171717;--muted:#686f7a;--line:#e3e0d8;--brand:#111811;--accent:#19a974;--amber:#f0b429;--blue:#2563eb;--danger:#b42318;--soft:#f9faf7}
*{box-sizing:border-box}
body{margin:0;font-family:Inter,Arial,sans-serif;background:var(--bg);color:var(--ink)}
button,input,textarea,select{font:inherit}
button{min-height:40px;border:0;background:var(--brand);color:white;padding:10px 14px;border-radius:8px;cursor:pointer;font-weight:700}
button:hover{filter:brightness(1.06)}
button:focus-visible,input:focus-visible,textarea:focus-visible{outline:3px solid #19a97433;outline-offset:2px}
input,textarea{width:100%;border:1px solid var(--line);border-radius:8px;padding:12px;background:white;color:var(--ink)}
textarea{min-height:124px;resize:vertical;line-height:1.45}
label{display:grid;gap:8px;font-weight:700;color:#30343b}
.appShell{min-height:100vh;display:grid;grid-template-rows:auto 1fr}
header{position:sticky;top:0;z-index:3;background:#101510;color:white;border-bottom:1px solid #ffffff12}
.topbar{display:grid;grid-template-columns:minmax(210px,1fr) auto auto;align-items:center;gap:16px;padding:14px 18px}
.brand{display:flex;align-items:center;gap:12px;min-width:0}
.mark{display:grid;place-items:center;width:38px;height:38px;border-radius:8px;background:var(--accent);color:#07120c;font-weight:900}
.brand strong{display:block;font-size:18px;line-height:1}
.brand span{display:block;margin-top:4px;color:#c9d2ca;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.statusPill{border:1px solid #ffffff24;background:#ffffff10;color:#e9f7ef;padding:8px 10px;border-radius:8px;font-size:12px;font-weight:700;white-space:nowrap}
.tabs{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}
.tabs button{background:transparent;color:#dce7df;border:1px solid transparent;border-radius:8px;padding:9px 12px}
.tabs button.active{background:white;color:#101510}
main{display:grid;grid-template-columns:360px minmax(0,1fr);min-height:calc(100vh - 67px)}
aside{background:var(--surface);border-right:1px solid var(--line);overflow:auto}
.sideHead{position:sticky;top:67px;background:var(--surface);z-index:1;padding:18px 16px 12px;border-bottom:1px solid var(--line)}
.sideTitle{font-size:12px;color:var(--muted);font-weight:900;text-transform:uppercase}
.sideSearch{margin-top:10px}
.row{display:grid;grid-template-columns:38px minmax(0,1fr);gap:12px;padding:14px 16px;border-bottom:1px solid #efede7;cursor:pointer;background:white}
.row:hover,.row.active{background:#f4fbf7}
.avatar{display:grid;place-items:center;width:38px;height:38px;border-radius:8px;background:#e8f7ef;color:#0b6b47;font-weight:900}
.rowMain{min-width:0}
.rowTop{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:5px}
.row b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.row time{font-size:11px;color:var(--muted);white-space:nowrap}
.row small{display:block;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.3}
.badge{display:inline-flex;align-items:center;border-radius:8px;padding:6px 9px;font-size:12px;font-weight:800}
.badge.auto{background:#e8f7ef;color:#0b6b47}.badge.human{background:#fff4d6;color:#7a4b00}.badge.quiet{background:#eef2ff;color:#273b8a}
.panel{padding:22px;max-width:1180px;width:100%}
.pageHead{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:18px}
.pageHead h1{margin:0;font-size:26px;letter-spacing:0;line-height:1.12}
.pageHead p{margin:7px 0 0;color:var(--muted);line-height:1.4}
.actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.ghost{background:#ece9e2;color:#171717}.danger{background:var(--danger)}
.grid{display:grid;gap:14px}.two{grid-template-columns:1fr 1fr}
.card{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:16px;margin-bottom:16px;box-shadow:0 1px 0 #ffffff inset}
.metricRow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:16px}
.metric{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:14px}
.metric span{display:block;color:var(--muted);font-size:12px;font-weight:800;text-transform:uppercase}.metric b{display:block;margin-top:8px;font-size:24px}
.messages{display:flex;flex-direction:column;gap:10px;margin:0 0 16px}
.msg{max-width:min(780px,88%);padding:12px 14px;border-radius:8px;background:white;border:1px solid var(--line);line-height:1.45;box-shadow:0 1px 0 #ffffff inset}
.msg b{display:block;margin-bottom:6px;font-size:12px;text-transform:uppercase;color:var(--muted)}
.cliente,.client{align-self:flex-start}.agente,.agent{align-self:flex-end;background:#eef5ff;border-color:#cfe0ff}.humano,.human{align-self:flex-end;background:#eaf8f0;border-color:#bfe8cf}
.composer{display:grid;gap:10px}
.composerFooter{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.muted{color:var(--muted)}.hide{display:none}.result{white-space:pre-wrap;background:#111827;color:#e5e7eb;border-radius:8px;padding:13px;min-height:56px;line-height:1.45}
.empty{display:grid;place-items:center;min-height:380px;text-align:center;color:var(--muted);border:1px dashed #d5d0c7;border-radius:8px;background:#fbfaf7;padding:28px}
.trainingItem p{margin:8px 0 14px;color:#343941;line-height:1.45}
@media(max-width:940px){.topbar{grid-template-columns:1fr}.tabs{justify-content:flex-start}main{grid-template-columns:1fr}aside{max-height:34vh;border-right:0;border-bottom:1px solid var(--line)}.sideHead{top:0}.panel{padding:16px}.metricRow,.two{grid-template-columns:1fr}.pageHead{flex-direction:column}.actions{justify-content:flex-start}.msg{max-width:96%}}
@media(max-width:560px){.topbar{padding:12px}.brand span{white-space:normal}.tabs button{flex:1}.panel{padding:12px}.card{padding:14px}.row{grid-template-columns:34px minmax(0,1fr);padding:12px}.avatar{width:34px;height:34px}.pageHead h1{font-size:22px}}
</style>
</head>
<body>
<div class="appShell">
<header><div class="topbar"><div class="brand"><div class="mark">HG</div><div><strong>High Games</strong><span>Painel de atendimento com IA</span></div></div><span class="statusPill" id="status">Carregando</span><nav class="tabs" aria-label="Navegacao principal"><button id="tab-chat" onclick="show('chat')">Conversas</button><button id="tab-train" onclick="show('train')">Treinar IA</button><button id="tab-settings" onclick="show('settings')">Ajustes</button></nav></div></header>
<main><aside><div class="sideHead"><div class="sideTitle">Conversas recentes</div><input class="sideSearch" id="search" placeholder="Buscar contato" oninput="renderList()"></div><div id="list"></div></aside><section class="panel" id="chat"></section><section class="panel hide" id="train"></section><section class="panel hide" id="settings"></section></main>
</div>
<script>
let state={conversations:[],training:[],settings:{}},current=null,active='chat',draft={tt:'',tc:'',testmsg:'',manual:'',sp:null,bk:null,mt:null,temp:null},dirty=false;
document.addEventListener('input',e=>{if(e.target&&['INPUT','TEXTAREA'].includes(e.target.tagName))dirty=true});
function captureDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el)draft[id]=el.value}}
function restoreDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp']){const el=document.getElementById(id);if(el&&draft[id]!==null&&draft[id]!==undefined)el.value=draft[id]}}
async function load(opts={}){captureDraft();state=await(await fetch('/api/state')).json();renderList();if(opts.force||active==='chat')renderChat();if((opts.force||active==='train')&&!dirty)renderTrain();if((opts.force||active==='settings')&&!dirty)renderSettings();restoreDraft()}
function show(id){captureDraft();active=id;for(const el of document.querySelectorAll('section.panel'))el.classList.add('hide');for(const el of document.querySelectorAll('.tabs button'))el.classList.remove('active');document.getElementById(id).classList.remove('hide');const tab=document.getElementById('tab-'+id);if(tab)tab.classList.add('active');if(id==='chat')renderChat();if(id==='train')renderTrain();if(id==='settings')renderSettings();restoreDraft()}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function roleLabel(role){return {cliente:'Cliente',client:'Cliente',agente:'IA',agent:'IA',humano:'Humano',human:'Humano'}[role]||role||'Mensagem'}
function keywordText(value){return Array.isArray(value)?value.join(', '):String(value||'')}
function initials(value){const clean=String(value||'HG').replace(/\\D/g,'');return clean.slice(-2)||'HG'}
function when(value){if(!value)return '';const date=new Date(value);if(Number.isNaN(date.getTime()))return '';return date.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})}
function filteredConversations(){const q=String(document.getElementById('search')?.value||'').trim().toLowerCase();return q?state.conversations.filter(c=>String(c.contact).toLowerCase().includes(q)):state.conversations}
function renderList(){const conversations=filteredConversations();const total=state.conversations.length||0;const human=state.conversations.filter(c=>c.humanMode).length;document.getElementById('status').textContent=total+' conversas | '+human+' humanas';list.innerHTML=conversations.map(c=>{const last=c.messages.at(-1)||{};return '<div class="row '+(c.contact===current?'active':'')+'" onclick="current=\\''+c.contact+'\\';show(\\'chat\\')"><div class="avatar">'+esc(initials(c.contact))+'</div><div class="rowMain"><div class="rowTop"><b>'+esc(c.contact)+'</b><time>'+when(c.updatedAt)+'</time></div><small>'+esc(last.text||'Sem mensagens')+'</small></div></div>'}).join('')||'<div class="empty">Nenhuma conversa encontrada.</div>'}
function conv(){return state.conversations.find(c=>c.contact===current)||state.conversations[0]}
function renderChat(){const c=conv();if(!c){chat.innerHTML='<div class="empty"><div><h1>Conversas</h1><p>As novas mensagens do WhatsApp vao aparecer aqui.</p></div></div>';return}current=c.contact;renderList();const badge=c.humanMode?'<span class="badge human">Humano ativo</span>':'<span class="badge auto">IA respondendo</span>';chat.innerHTML='<div class="pageHead"><div><h1>'+esc(c.contact)+'</h1><p>'+esc((c.messages.length||0)+' mensagens registradas nesta conversa')+'</p></div><div class="actions">'+badge+'<button class="ghost" onclick="toggleHuman('+!c.humanMode+')">'+(c.humanMode?'Ativar IA':'Assumir humano')+'</button></div></div><div class="messages">'+c.messages.map(m=>'<div class="msg '+esc(m.role)+'"><b>'+esc(roleLabel(m.role))+'</b>'+esc(m.text)+'</div>').join('')+'</div><div class="card composer"><textarea id="manual" placeholder="Escreva uma resposta manual"></textarea><div class="composerFooter"><span class="muted">Ao enviar, a mensagem vai para este contato.</span><button onclick="sendManual()">Enviar resposta</button></div></div>'}
function renderTrain(){train.innerHTML='<div class="pageHead"><div><h1>Base de treinamento</h1><p>Cadastre orientacoes que a IA deve considerar nas proximas respostas.</p></div><span class="badge quiet">'+state.training.length+' itens</span></div><div class="metricRow"><div class="metric"><span>Treinamentos</span><b>'+state.training.length+'</b></div><div class="metric"><span>Conversas</span><b>'+state.conversations.length+'</b></div><div class="metric"><span>Modo humano</span><b>'+state.conversations.filter(c=>c.humanMode).length+'</b></div></div><div class="card grid"><label>Titulo do treinamento<input id="tt" placeholder="Ex.: Venda consultiva"></label><label>Conteudo<textarea id="tc" placeholder="Ex.: Quando o cliente pedir um jogo, pergunte o modelo do celular antes de falar de pagamento."></textarea></label><div class="actions"><button onclick="saveTraining()">Salvar treinamento</button></div></div><div class="card grid"><h2>Teste rapido</h2><textarea id="testmsg" placeholder="Digite uma mensagem de cliente para testar sem enviar no WhatsApp"></textarea><div class="actions"><button onclick="testReply()">Gerar resposta de teste</button></div><div class="result" id="testout">O resultado aparecera aqui.</div></div>'+state.training.map(t=>'<div class="card trainingItem"><b>'+esc(t.title)+'</b><p>'+esc(t.content)+'</p><button class="danger" onclick="deleteTraining(\\''+t.id+'\\')">Excluir</button></div>').join('')}
function renderSettings(){settings.innerHTML='<div class="pageHead"><div><h1>Ajustes da IA</h1><p>Essas configuracoes entram nas proximas respostas geradas.</p></div></div><div class="card grid"><label>Prompt principal<textarea id="sp">'+esc(state.settings.systemPrompt)+'</textarea></label><label>Conhecimento do negocio<textarea id="bk">'+esc(state.settings.businessKnowledge)+'</textarea></label><div class="grid two"><label>Max tokens<input id="mt" value="'+(state.settings.maxOutputTokens||2048)+'"></label><label>Temperatura<input id="temp" value="'+(state.settings.temperature||0.45)+'"></label></div><div class="actions"><button onclick="saveSettings()">Salvar ajustes</button></div></div>'}
async function saveTraining(){await fetch('/api/training',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:tt.value,content:tc.value})});draft.tt='';draft.tc='';dirty=false;await load({force:true})}
async function deleteTraining(id){dirty=false;await fetch('/api/training',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({id})});await load({force:true})}
async function testReply(){testout.textContent='Gerando...';const r=await fetch('/api/test-reply',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:testmsg.value})});const j=await r.json();testout.textContent=j.reply||JSON.stringify(j)}
async function saveSettings(){await fetch('/api/settings',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({systemPrompt:sp.value,businessKnowledge:bk.value,maxOutputTokens:Number(mt.value||2048),temperature:Number(temp.value||0.45)})});draft.sp=null;draft.bk=null;draft.mt=null;draft.temp=null;dirty=false;await load({force:true})}
async function toggleHuman(v){await fetch('/api/conversation',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,humanMode:v})});await load({force:true})}
async function sendManual(){await fetch('/api/send',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,text:manual.value})});draft.manual='';await load({force:true})}
show('chat');load({force:true});setInterval(()=>load(),5000);
</script>
</body>
</html>`;
}

function adminHtmlModern() {
  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>High Games Admin</title>
<style>
:root{--page:#f6f7fb;--panel:#ffffff;--panel-2:#faf8ff;--ink:#161625;--muted:#707089;--line:#e7e3f3;--deep:#211332;--deep-2:#2d1746;--purple:#7c3aed;--purple-2:#a855f7;--fresh:#22d3ee;--mint:#2dd4bf;--success:#13a36b;--warning:#b7791f;--danger:#d92d20;--shadow:0 18px 44px rgba(40,22,75,.13)}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;font-family:Inter,Arial,sans-serif;background:var(--page);color:var(--ink)}
button,input,textarea{font:inherit}
button{min-height:40px;border:0;border-radius:8px;background:linear-gradient(135deg,var(--purple),#5b21b6);color:white;padding:10px 14px;font-weight:800;cursor:pointer;box-shadow:0 10px 20px rgba(124,58,237,.18)}
button:hover{filter:brightness(1.04)}
button:disabled{opacity:.55;cursor:not-allowed}
input,textarea,select{width:100%;border:1px solid var(--line);border-radius:8px;background:white;color:var(--ink);padding:12px}
textarea{min-height:122px;resize:vertical;line-height:1.45}
label{display:grid;gap:8px;font-weight:800;color:#28243b}
button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:3px solid rgba(34,211,238,.35);outline-offset:2px}
.app{min-height:100vh;display:grid;grid-template-columns:250px minmax(0,1fr)}
.sidebar{background:linear-gradient(180deg,var(--deep),var(--deep-2));color:white;padding:18px 14px;display:flex;flex-direction:column;gap:18px;box-shadow:12px 0 34px rgba(33,19,50,.16)}
.brand{display:flex;align-items:center;gap:12px;padding:4px 6px}
.logo{display:grid;place-items:center;width:42px;height:42px;border-radius:8px;background:linear-gradient(135deg,var(--fresh),var(--mint));color:#101026;font-weight:950}
.brand strong{display:block;font-size:18px;line-height:1}
.brand span{display:block;margin-top:4px;color:#d8cced;font-size:12px}
.company{border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.07);border-radius:8px;padding:12px}
.company small{display:block;color:#cbbbe8;font-weight:800;text-transform:uppercase;font-size:11px}.company b{display:block;margin-top:5px}
.nav{display:grid;gap:8px}
.nav button{box-shadow:none;background:transparent;color:#eee8fb;text-align:left;display:flex;align-items:center;gap:10px;border:1px solid transparent}
.nav button.active{background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.14)}
.navIcon{display:grid;place-items:center;width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.1);font-size:12px}
.sideFoot{margin-top:auto;border-top:1px solid rgba(255,255,255,.12);padding-top:14px;color:#d8cced;font-size:12px;line-height:1.45}
.workspace{min-width:0;display:grid;grid-template-rows:auto 1fr}
.topbar{height:70px;background:rgba(255,255,255,.82);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:16px;padding:0 22px;position:sticky;top:0;z-index:2}
.topbar h1{margin:0;font-size:20px;letter-spacing:0}.topbar p{margin:4px 0 0;color:var(--muted);font-size:13px}
.status{display:inline-flex;align-items:center;border:1px solid var(--line);background:#fff;border-radius:8px;padding:9px 11px;font-weight:900;font-size:12px;color:#35224e}
.content{padding:20px}
.chatGrid{display:grid;grid-template-columns:350px minmax(0,1fr);gap:18px;min-height:calc(100vh - 110px)}
.inbox,.chatPane,.fullPane,.card{background:var(--panel);border:1px solid var(--line);border-radius:8px;box-shadow:var(--shadow)}
.inbox{overflow:hidden;display:grid;grid-template-rows:auto 1fr}
.inboxHead{padding:16px;border-bottom:1px solid var(--line);background:linear-gradient(180deg,#fff,var(--panel-2))}
.inboxHead strong{display:block;font-size:15px}.inboxHead span{display:block;margin-top:4px;color:var(--muted);font-size:12px}
.search{margin-top:12px}
.list{overflow:auto}
.row{display:grid;grid-template-columns:42px minmax(0,1fr);gap:12px;padding:13px 14px;border-bottom:1px solid #eee9f8;cursor:pointer}
.row:hover,.row.active{background:#f7f2ff}
.avatar{display:grid;place-items:center;width:42px;height:42px;border-radius:8px;background:#ede4ff;color:#5b21b6;font-weight:950}
.rowMain{min-width:0}.rowTop{display:flex;justify-content:space-between;gap:8px;margin-bottom:5px}.row b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row time{font-size:11px;color:var(--muted);white-space:nowrap}.row small{display:block;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.35}
.chatPane{display:grid;grid-template-rows:auto 1fr auto;overflow:hidden}
.chatHead{padding:18px;border-bottom:1px solid var(--line);background:linear-gradient(135deg,#fff,#f6edff);display:flex;justify-content:space-between;gap:14px;align-items:flex-start}
.chatHead h2{margin:0;font-size:23px}.chatHead p{margin:6px 0 0;color:var(--muted)}
.actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.ghost{background:#f0ecf8;color:#2e2340;box-shadow:none}.danger{background:var(--danger);box-shadow:none}
.badge{display:inline-flex;align-items:center;border-radius:8px;padding:7px 10px;font-size:12px;font-weight:900;white-space:nowrap}
.badge.auto{background:#e6fbf7;color:#087968}.badge.human{background:#fff3d8;color:#805200}.badge.quiet{background:#f0e8ff;color:#5b21b6}
.messages{padding:18px;display:flex;flex-direction:column;gap:12px;overflow:auto;background:linear-gradient(180deg,#fbf9ff,#f7f8fb)}
.msg{max-width:min(760px,86%);padding:12px 14px;border:1px solid var(--line);border-radius:8px;background:white;line-height:1.45;box-shadow:0 8px 20px rgba(37,24,63,.06)}
.msg b{display:block;margin-bottom:7px;color:var(--muted);font-size:11px;text-transform:uppercase}.cliente,.client{align-self:flex-start}.agente,.agent{align-self:flex-end;background:#f1e9ff;border-color:#dcc7ff}.humano,.human{align-self:flex-end;background:#e8fbff;border-color:#bceefa}
.composer{padding:14px;border-top:1px solid var(--line);background:white;display:grid;gap:10px}.composer textarea{min-height:92px}.composerFooter{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.muted{color:var(--muted)}.hide{display:none!important}
.fullPane{padding:18px;max-width:1120px}.pageHead{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:18px}.pageHead h2{margin:0;font-size:26px}.pageHead p{margin:7px 0 0;color:var(--muted);line-height:1.45}
.metricRow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:16px}.metric{background:linear-gradient(135deg,#fff,#f7f1ff);border:1px solid var(--line);border-radius:8px;padding:16px}.metric span{display:block;color:var(--muted);font-size:12px;font-weight:900;text-transform:uppercase}.metric b{display:block;margin-top:8px;font-size:28px}
.grid{display:grid;gap:14px}.two{grid-template-columns:1fr 1fr}.card{box-shadow:none;padding:16px;margin-bottom:16px}.result{white-space:pre-wrap;background:#171125;color:#f4efff;border-radius:8px;padding:13px;min-height:58px;line-height:1.45}.trainingItem p{margin:8px 0 14px;color:#343146;line-height:1.45}
.empty{display:grid;place-items:center;text-align:center;min-height:360px;color:var(--muted);border:1px dashed #d8d0ea;border-radius:8px;background:#fbf9ff;padding:28px}
@media(max-width:1050px){.app{grid-template-columns:1fr}.sidebar{position:sticky;top:0;z-index:4;display:grid;grid-template-columns:1fr;gap:12px}.company,.sideFoot{display:none}.nav{grid-template-columns:repeat(5,1fr)}.nav button{justify-content:center}.topbar{top:154px}.chatGrid{grid-template-columns:1fr}.inbox{max-height:320px}}
@media(max-width:620px){.sidebar{padding:12px}.brand span{display:none}.nav{grid-template-columns:1fr}.nav button{justify-content:flex-start}.topbar{height:auto;align-items:flex-start;flex-direction:column;padding:14px}.content{padding:12px}.chatHead,.pageHead{flex-direction:column}.metricRow,.two{grid-template-columns:1fr}.msg{max-width:96%}.composerFooter button{width:100%}}
.backBtn{display:none}
@media(max-width:720px){
html,body{height:100%;overflow:hidden;background:#f0f2f5}
button{box-shadow:none}
.app{display:block;min-height:100dvh;background:#f0f2f5}
.sidebar{position:fixed;left:0;right:0;bottom:0;top:auto;z-index:20;height:64px;padding:6px;background:#fff;color:#1f2937;border-top:1px solid #d7dce2;box-shadow:0 -8px 24px rgba(15,23,42,.12);display:block}
.brand,.company,.sideFoot{display:none!important}
.nav{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;height:100%}
.nav button{min-height:52px;padding:6px 2px;border-radius:8px;background:transparent;color:#64748b;display:grid;place-items:center;text-align:center;font-size:11px;font-weight:800}
.nav button.active{background:#e7f6ef;color:#075e54}
.navIcon{display:none}
.workspace{height:calc(100dvh - 64px);display:block}
.topbar{display:none}
.content{height:100%;padding:0;overflow:hidden}
.chatGrid{display:block;position:relative;height:100%;min-height:0}
.inbox,.chatPane{position:absolute;inset:0;border:0;border-radius:0;box-shadow:none;background:#fff}
.inbox{display:grid;grid-template-rows:auto 1fr;max-height:none;z-index:1}
.chatPane{display:none;grid-template-rows:58px minmax(0,1fr) auto;z-index:2}
.chatGrid.mobileOpen .inbox{display:none}
.chatGrid.mobileOpen .chatPane{display:grid}
.inboxHead{padding:14px;background:#fff;border-bottom:1px solid #e5e7eb}
.inboxHead strong{font-size:22px;line-height:1.1;color:#111827}
.inboxHead span{display:none}
.search{height:42px;margin-top:12px;border-radius:8px;background:#f0f2f5;border:0}
.list{overflow:auto;-webkit-overflow-scrolling:touch}
.row{grid-template-columns:46px minmax(0,1fr);gap:11px;padding:12px 14px;border-bottom:1px solid #eef0f3}
.row:hover,.row.active{background:#f6fbf8}
.avatar{width:46px;height:46px;border-radius:50%;background:#dce7e2;color:#075e54}
.rowTop{margin-bottom:4px}.row b{font-size:15px}.row small{font-size:13px}
.chatHead{height:58px;padding:8px 10px;background:#075e54;color:white;border:0;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:8px}
.chatHead h2{font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:white}
.chatHead p{display:none}
.chatHead .actions{justify-content:flex-end;gap:6px;flex-wrap:nowrap}
.chatHead .badge{display:none}
.chatHead .ghost{min-height:36px;padding:8px 9px;background:rgba(255,255,255,.16);color:white}
.backBtn{display:inline-grid;place-items:center;min-width:42px;min-height:42px;padding:0;background:transparent;color:white;border-radius:8px}
.messages{padding:12px;gap:7px;background:#efeae2;overflow:auto;-webkit-overflow-scrolling:touch}
.msg{max-width:84%;padding:8px 10px;border:0;border-radius:8px;background:#fff;box-shadow:0 1px 1px rgba(15,23,42,.08);font-size:14px;line-height:1.38}
.msg b{margin-bottom:4px;font-size:10px;color:#667085}
.agente,.agent,.humano,.human{background:#d9fdd3;border:0}
.composer{padding:8px;background:#f0f2f5;border-top:1px solid #d7dce2;display:grid;gap:8px}
.composer textarea{min-height:44px;max-height:116px;border:0;border-radius:8px;background:white;padding:12px;resize:none}
.composerFooter{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}
.composerFooter .muted{display:none}
.composerFooter button{width:auto;min-height:44px;border-radius:8px;background:#008069;padding:10px 14px}
.fullPane{height:100%;overflow:auto;padding:12px 12px 76px;border:0;border-radius:0;box-shadow:none;background:#f6f7fb}
.pageHead{flex-direction:column;margin-bottom:12px}.pageHead h2{font-size:22px}
.metricRow,.two{grid-template-columns:1fr}
.card{padding:14px;border-radius:8px;box-shadow:none}
.actions{justify-content:flex-start}.actions button{width:100%}
.empty{min-height:260px;border:0;background:#fff}
}
</style>
</head>
<body>
<div class="app">
  <aside class="sidebar">
    <div class="brand"><div class="logo">HG</div><div><strong>High Games</strong><span>Atendimento com IA</span></div></div>
    <div class="company"><small>Companhia selecionada</small><b>WhatsApp High Games</b></div>
    <nav class="nav" aria-label="Menu principal">
      <button id="nav-chat" onclick="openInboxTab()"><span class="navIcon">01</span> Bate papo</button>
      <button id="nav-train" onclick="show('train')"><span class="navIcon">02</span> Treinar IA</button>
      <button id="nav-products" onclick="show('products')"><span class="navIcon">03</span> Produtos</button>
      <button id="nav-payments" onclick="show('payments')"><span class="navIcon">04</span> Comprovantes</button>
      <button id="nav-settings" onclick="show('settings')"><span class="navIcon">05</span> Ajustes</button>
    </nav>
    <div class="sideFoot">Inspirado em fluxos de atendimento, CRM e automacao de WhatsApp. Simples para operar no dia a dia.</div>
  </aside>
  <div class="workspace">
    <header class="topbar"><div><h1 id="pageTitle">Bate papo</h1><p id="pageSubtitle">Acompanhe conversas e assuma quando precisar.</p></div><span class="status" id="status">Carregando</span></header>
    <main class="content">
      <section class="chatGrid" id="chatView"><aside class="inbox"><div class="inboxHead"><strong>Caixa de entrada</strong><span>Contatos recentes do WhatsApp</span><input class="search" id="search" placeholder="Buscar contato" oninput="renderList()"></div><div class="list" id="list"></div></aside><div class="chatPane" id="chat"></div></section>
      <section class="fullPane hide" id="train"></section>
      <section class="fullPane hide" id="products"></section>
      <section class="fullPane hide" id="payments"></section>
      <section class="fullPane hide" id="settings"></section>
    </main>
  </div>
</div>
<script>
let state={conversations:[],training:[],products:[],paymentReviews:[],settings:{}},current=null,active='chat',mobileChatOpen=false,draft={tt:'',tc:'',testmsg:'',manual:'',sp:null,bk:null,mt:null,temp:null,pn:'',pk:'',pp:'',pa:''},dirty=false;
document.addEventListener('input',e=>{if(e.target&&['INPUT','TEXTAREA'].includes(e.target.tagName))dirty=true});
function captureDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp','pn','pk','pp','pa']){const el=document.getElementById(id);if(el)draft[id]=el.value}}
function restoreDraft(){for(const id of ['tt','tc','testmsg','manual','sp','bk','mt','temp','pn','pk','pp','pa']){const el=document.getElementById(id);if(el&&draft[id]!==null&&draft[id]!==undefined)el.value=draft[id]}}
async function load(opts={}){captureDraft();const editing=document.activeElement&&['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName);state=await(await fetch('/api/state')).json();state.products=state.products||[];state.paymentReviews=state.paymentReviews||[];renderList();if((opts.force||active==='chat')&&(!editing||opts.force))renderChat();if((opts.force||active==='train')&&!dirty)renderTrain();if((opts.force||active==='products')&&!dirty)renderProducts();if((opts.force||active==='payments')&&!dirty)renderPayments();if((opts.force||active==='settings')&&!dirty)renderSettings();restoreDraft()}
function show(id){captureDraft();active=id;if(id==='chat'&&isMobile()&&!mobileChatOpen)mobileChatOpen=false;for(const el of document.querySelectorAll('.nav button'))el.classList.remove('active');const nav=document.getElementById('nav-'+id);if(nav)nav.classList.add('active');chatView.classList.toggle('hide',id!=='chat');train.classList.toggle('hide',id!=='train');products.classList.toggle('hide',id!=='products');payments.classList.toggle('hide',id!=='payments');settings.classList.toggle('hide',id!=='settings');pageTitle.textContent=id==='chat'?'Bate papo':id==='train'?'Treinar IA':id==='products'?'Produtos e acessos':id==='payments'?'Comprovantes':'Ajustes';pageSubtitle.textContent=id==='chat'?'Acompanhe conversas e assuma quando precisar.':id==='train'?'Ensine respostas, regras e contexto do negocio.':id==='products'?'Cadastre jogos, precos e mensagens de entrega.':id==='payments'?'Aprove comprovantes antes de liberar acessos.':'Controle o comportamento da inteligencia artificial.';if(id==='chat')renderChat();if(id==='train')renderTrain();if(id==='products')renderProducts();if(id==='payments')renderPayments();if(id==='settings')renderSettings();restoreDraft()}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function roleLabel(role){return {cliente:'Cliente',client:'Cliente',agente:'IA',agent:'IA',humano:'Humano',human:'Humano'}[role]||role||'Mensagem'}
function initials(value){const clean=String(value||'HG').replace(/\\D/g,'');return clean.slice(-2)||'HG'}
function when(value){if(!value)return '';const date=new Date(value);if(Number.isNaN(date.getTime()))return '';return date.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})}
function filteredConversations(){const q=String(document.getElementById('search')?.value||'').trim().toLowerCase();return q?state.conversations.filter(c=>String(c.contact).toLowerCase().includes(q)):state.conversations}
function isMobile(){return window.matchMedia('(max-width:720px)').matches}
function openInboxTab(){if(isMobile())mobileChatOpen=false;show('chat')}
function openConversation(contact){current=contact;mobileChatOpen=true;show('chat');setTimeout(scrollMessages,0)}
function backToInbox(){mobileChatOpen=false;renderChat();renderList()}
function scrollMessages(){const el=document.querySelector('.messages');if(el)el.scrollTop=el.scrollHeight}
function renderList(){const conversations=filteredConversations();const total=state.conversations.length||0;const human=state.conversations.filter(c=>c.humanMode).length;document.getElementById('status').textContent=total+' conversas | '+human+' humanas';list.innerHTML=conversations.map(c=>{const last=c.messages.at(-1)||{};return '<div class="row '+(c.contact===current?'active':'')+'" onclick="openConversation(\\''+c.contact+'\\')"><div class="avatar">'+esc(initials(c.contact))+'</div><div class="rowMain"><div class="rowTop"><b>'+esc(c.contact)+'</b><time>'+when(c.updatedAt)+'</time></div><small>'+esc(last.text||'Sem mensagens')+'</small></div></div>'}).join('')||'<div class="empty">Nenhuma conversa encontrada.</div>'}
function conv(){return state.conversations.find(c=>c.contact===current)||state.conversations[0]}
function renderChat(){const c=conv();const cv=document.getElementById('chatView');if(cv)cv.classList.toggle('mobileOpen',Boolean(c&&mobileChatOpen&&isMobile()));if(!c){chat.innerHTML='<div class="empty"><div><h2>Nenhuma conversa ainda</h2><p>As mensagens novas do WhatsApp vao aparecer nesta tela.</p></div></div>';return}current=c.contact;renderList();const badge=c.humanMode?'<span class="badge human">Humano ativo</span>':'<span class="badge auto">IA respondendo</span>';chat.innerHTML='<div class="chatHead"><button class="backBtn" onclick="backToInbox()">Voltar</button><div><h2>'+esc(c.contact)+'</h2><p>'+esc((c.messages.length||0)+' mensagens registradas nesta conversa')+'</p></div><div class="actions">'+badge+'<button class="ghost" onclick="toggleHuman('+!c.humanMode+')">'+(c.humanMode?'Ativar IA':'Assumir humano')+'</button></div></div><div class="messages">'+c.messages.map(m=>'<div class="msg '+esc(m.role)+'"><b>'+esc(roleLabel(m.role))+'</b>'+esc(m.text)+'</div>').join('')+'</div><div class="composer"><textarea id="manual" placeholder="Escreva uma resposta manual"></textarea><div class="composerFooter"><span class="muted">Ao enviar, a mensagem vai para este contato.</span><button onclick="sendManual()">Enviar</button></div></div>';setTimeout(scrollMessages,0)}
function renderTrain(){train.innerHTML='<div class="pageHead"><div><h2>Base de treinamento</h2><p>Adicione orientacoes que a IA deve seguir nas proximas conversas.</p></div><span class="badge quiet">'+state.training.length+' itens ativos</span></div><div class="metricRow"><div class="metric"><span>Treinamentos</span><b>'+state.training.length+'</b></div><div class="metric"><span>Conversas</span><b>'+state.conversations.length+'</b></div><div class="metric"><span>Modo humano</span><b>'+state.conversations.filter(c=>c.humanMode).length+'</b></div></div><div class="card grid"><label>Titulo do treinamento<input id="tt" placeholder="Ex.: Venda consultiva"></label><label>Conteudo<textarea id="tc" placeholder="Ex.: Quando o cliente pedir um jogo, pergunte o modelo do celular antes de falar de pagamento."></textarea></label><div class="actions"><button onclick="saveTraining()">Salvar treinamento</button></div></div><div class="card grid"><h2>Teste rapido</h2><textarea id="testmsg" placeholder="Digite uma mensagem de cliente para testar sem enviar no WhatsApp"></textarea><div class="actions"><button onclick="testReply()">Gerar resposta de teste</button></div><div class="result" id="testout">O resultado aparecera aqui.</div></div>'+state.training.map(t=>'<div class="card trainingItem"><b>'+esc(t.title)+'</b><p>'+esc(t.content)+'</p><button class="danger" onclick="deleteTraining(\\''+t.id+'\\')">Excluir</button></div>').join('')}
function renderProducts(){products.innerHTML='<div class="pageHead"><div><h2>Produtos e acessos</h2><p>Cadastre o que a IA pode entregar apos aprovacao do comprovante.</p></div><span class="badge quiet">'+state.products.length+' produtos</span></div><div class="card grid"><div class="grid two"><label>Nome do jogo ou pack<input id="pn" placeholder="Ex.: God of War 2"></label><label>Preco esperado<input id="pp" placeholder="Ex.: 11,90"></label></div><label>Palavras-chave<input id="pk" placeholder="Ex.: god of war, gow2, god 2"></label><label>Mensagem de entrega<textarea id="pa" placeholder="Cole aqui o link de acesso e o passo a passo que o cliente deve receber."></textarea></label><div class="actions"><button onclick="saveProduct()">Salvar produto</button></div></div>'+state.products.map(p=>'<div class="card trainingItem"><b>'+esc(p.name)+'</b><p><b>Preco:</b> '+esc(p.price||'Nao informado')+'<br><b>Palavras:</b> '+esc(keywordText(p.keywords))+'</p><p>'+esc(p.accessMessage||'')+'</p><button class="danger" onclick="deleteProduct(\\''+p.id+'\\')">Excluir</button></div>').join('')}
function renderPayments(){const pending=state.paymentReviews.filter(r=>r.status==='pending').length;payments.innerHTML='<div class="pageHead"><div><h2>Comprovantes</h2><p>Revise pagamentos antes de liberar acessos automaticamente.</p></div><span class="badge quiet">'+pending+' pendentes</span></div>'+state.paymentReviews.map(r=>{const productOptions=state.products.map(p=>'<option value="'+esc(p.id)+'" '+(p.id===r.productId?'selected':'')+'>'+esc(p.name)+'</option>').join('');return '<div class="card trainingItem"><b>'+esc(r.contact)+' - '+esc(r.status)+'</b><p>'+esc(r.summary||'Sem resumo')+'</p><p><b>Produto:</b> '+esc(r.productName||'Nao identificado')+'<br><b>Valor:</b> '+esc(r.amount||'Nao lido')+'<br><b>Confianca:</b> '+esc(r.confidence||'')+'<br><b>Mensagem:</b> '+esc(r.customerText||'')+'</p><div class="grid two"><select id="reviewProduct-'+esc(r.id)+'">'+productOptions+'</select><div class="actions"><button onclick="approvePayment(\\''+r.id+'\\')">Aprovar e enviar acesso</button><button class="danger" onclick="rejectPayment(\\''+r.id+'\\')">Rejeitar</button></div></div></div>'}).join('')||'<div class="empty"><div><h2>Nenhum comprovante ainda</h2><p>Quando um cliente enviar imagem ou PDF, ele aparecera aqui.</p></div></div>'}
function renderSettings(){settings.innerHTML='<div class="pageHead"><div><h2>Ajustes da IA</h2><p>Defina personalidade, conhecimento fixo e limites de resposta.</p></div></div><div class="card grid"><label>Prompt principal<textarea id="sp">'+esc(state.settings.systemPrompt)+'</textarea></label><label>Conhecimento do negocio<textarea id="bk">'+esc(state.settings.businessKnowledge)+'</textarea></label><div class="grid two"><label>Max tokens<input id="mt" value="'+(state.settings.maxOutputTokens||2048)+'"></label><label>Temperatura<input id="temp" value="'+(state.settings.temperature||0.45)+'"></label></div><label><input type="checkbox" id="autoRelease" '+(state.settings.autoReleaseAccess?'checked':'')+'> Liberar acesso automaticamente quando comprovante, valor e produto estiverem confiaveis</label><label><input type="checkbox" id="humanAlerts" '+(state.settings.humanSupportAlerts!==false?'checked':'')+'> Avisar meu WhatsApp quando precisar de suporte humano</label><div class="actions"><button onclick="saveSettings()">Salvar ajustes</button></div></div>'}
async function saveTraining(){await fetch('/api/training',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:tt.value,content:tc.value})});draft.tt='';draft.tc='';dirty=false;await load({force:true})}
async function deleteTraining(id){dirty=false;await fetch('/api/training',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({id})});await load({force:true})}
async function saveProduct(){await fetch('/api/products',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:pn.value,keywords:pk.value,price:pp.value,accessMessage:pa.value})});draft.pn='';draft.pk='';draft.pp='';draft.pa='';dirty=false;await load({force:true})}
async function deleteProduct(id){dirty=false;await fetch('/api/products',{method:'DELETE',headers:{'content-type':'application/json'},body:JSON.stringify({id})});await load({force:true})}
async function approvePayment(id){const el=document.getElementById('reviewProduct-'+id);await fetch('/api/payment-review',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,action:'approve',productId:el?el.value:''})});dirty=false;await load({force:true})}
async function rejectPayment(id){await fetch('/api/payment-review',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,action:'reject'})});dirty=false;await load({force:true})}
async function testReply(){testout.textContent='Gerando...';const r=await fetch('/api/test-reply',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:testmsg.value})});const j=await r.json();testout.textContent=j.reply||JSON.stringify(j)}
async function saveSettings(){await fetch('/api/settings',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({systemPrompt:sp.value,businessKnowledge:bk.value,maxOutputTokens:Number(mt.value||2048),temperature:Number(temp.value||0.45),autoReleaseAccess:Boolean(document.getElementById('autoRelease')?.checked),humanSupportAlerts:Boolean(document.getElementById('humanAlerts')?.checked)})});draft.sp=null;draft.bk=null;draft.mt=null;draft.temp=null;dirty=false;await load({force:true})}
async function toggleHuman(v){await fetch('/api/conversation',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,humanMode:v})});await load({force:true})}
async function sendManual(){await fetch('/api/send',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contact:current,text:manual.value})});draft.manual='';await load({force:true})}
show('chat');load({force:true});setInterval(()=>load(),5000);
</script>
</body>
</html>`;
}
